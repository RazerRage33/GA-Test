export interface Dashboard {
  companyCount?: string;
  projectCount?: string;
  contractCount?: string;
  ticketCount?: string;
  ticketSubmitted?: string;
  ticketInProgress?: string;
  ticketCompleted?: string;
  jobCount?: string;
  jobActionCount?: string;
  userCount?: string;
  userAvailable?: string;
}
