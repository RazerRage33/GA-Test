export interface User {
  username?: string;
  id?: string;
  email?: string;
  password?: string;
  companyName?: string;
  companyId?: string;
  type?: string;
  roleId?: string;
  phoneNumber?: string;
  logoPath?: string;
  status?: string;
  statusDescription?: string;
  workload?: string;

  // staff
  staffId?: string;
  statusName?: string;

  // user type query
  roleName?: string;

  //homepage link
  homePage?: string;
}
