export interface Password {
  oldPassword?: string;
  newPassword?: string;
  confirmNewPassword?: string;

  //reset password
  token?: string;
}
