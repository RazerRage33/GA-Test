export interface Ticket {
  id?: string;
  companyName?: string;
  projectName?: string;
  categoryName?: string;
  statusName?: string;
  statusDescription?: string;
  title?: string;
  description?: string;
  fileNameWithExtension?: string;
  imageNameWithExtension1?: string;
  imageNameWithExtension2?: string;
  skillName?: string;
  requestedBy?: string;
  requestedOn?: string;
  updatedBy?: string;
  updatedOn?: string;

  //upload image and file
  file?: File;
  image1?: File;
  image2?: File;

  //ticket category
  name?: string;

  //report
  reportPath?: string;

  //create job
  ticketId?: string;
  ticketSkill?: string;

  // create ticket
  contractId?: string;
}
