// default
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

// angular material
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatRadioModule } from '@angular/material/radio';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatChipsModule } from '@angular/material/chips';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { MatTabsModule } from '@angular/material/tabs';

// ng bootstrap
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

// prime ng
import { SelectButtonModule } from 'primeng/selectbutton';
import { TableModule } from 'primeng/table';
import { SkeletonModule } from 'primeng/skeleton';
import { ToastModule } from 'primeng/toast';
import { InputTextModule } from 'primeng/inputtext';
import { ProgressBarModule } from 'primeng/progressbar';
import { DropdownModule } from 'primeng/dropdown';

// components & functions
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavBarComponent } from './components/shared/nav-bar/nav-bar.component';
import { ErrorComponent } from './components/shared/error/error.component';
import { LoginPageComponent } from './components/shared/login/login.component';
import { ProfileComponent } from './components/shared/profile/profile.component';
import { AuthInterceptor } from './interceptor/auth.interceptor';
import { ChangePasswordComponent } from './dialogs/user/change-password/change-password.component';
import { UpdateProfileComponent } from './dialogs/user/update-profile/update-profile.component';
import { CompanyAstrioAdminComponent } from './components/astrio/admin/company-astrio-admin/company-astrio-admin.component';
import { ViewCompanyComponent } from './dialogs/company/view-company/view-company.component';
import { UpdateCompanyComponent } from './dialogs/company/update-company/update-company.component';
import { ForgotPasswordComponent } from './components/shared/forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './components/shared/reset-password/reset-password.component';
import { ProjectAstrioAdminComponent } from './components/astrio/admin/project-astrio-admin/project-astrio-admin.component';
import { UpdateProjectComponent } from './dialogs/project/update-project/update-project.component';
import { ViewProjectComponent } from './dialogs/project/view-project/view-project.component';
import { TicketAstrioComponent } from './components/astrio/shared/ticket-astrio/ticket-astrio.component';
import { UpdateTicketComponent } from './dialogs/ticket/update-ticket/update-ticket.component';
import { ViewTicketComponent } from './dialogs/ticket/view-ticket/view-ticket.component';
import { JobAstrioComponent } from './components/astrio/shared/job-astrio/job-astrio.component';
import { JobActionAstrioComponent } from './components/astrio/shared/job-action-astrio/job-action-astrio.component';
import { UserAstrioAdminComponent } from './components/astrio/admin/user-astrio-admin/user-astrio-admin.component';
import { UpdateActionComponent } from './dialogs/job/update-action/update-action.component';
import { UpdateUserComponent } from './dialogs/user/update-user/update-user.component';
import { ViewUserComponent } from './dialogs/user/view-user/view-user.component';
import { UpdateSkillComponent } from './dialogs/user/update-skill/update-skill.component';
import { ViewActionComponent } from './dialogs/job/view-action/view-action.component';
import { ProjectAstrioUserComponent } from './components/astrio/user/project-astrio-user/project-astrio-user.component';
import { TicketCompanyComponent } from './components/company/shared/ticket-company/ticket-company.component';
import { ProjectCompanyComponent } from './components/company/shared/project-company/project-company.component';
import { DashboardCompanyAdminComponent } from './components/company/admin/dashboard-company-admin/dashboard-company-admin.component';
import { UserCompanyAdminComponent } from './components/company/admin/user-company-admin/user-company-admin.component';
import { DashboardCompanyUserComponent } from './components/company/user/dashboard-company-user/dashboard-company-user.component';
import { DashboardAstrioAdminComponent } from './components/astrio/admin/dashboard-astrio-admin/dashboard-astrio-admin.component';
import { DashboardAstrioUserComponent } from './components/astrio/user/dashboard-astrio-user/dashboard-astrio-user.component';
import { ContractAstrioAdminComponent } from './components/astrio/admin/contract-astrio-admin/contract-astrio-admin.component';
import { ViewContractComponent } from './dialogs/contract/view-contract/view-contract.component';
import { UpdateContractComponent } from './dialogs/contract/update-contract/update-contract.component';
import { CloseActionComponent } from './dialogs/job/close-action/close-action.component';
import { CloseJobComponent } from './dialogs/job/close-job/close-job.component';
import { ToastComponent } from './components/shared/toast/toast.component';
import { ReportAstrioComponent } from './components/astrio/shared/report-astrio/report-astrio.component';
import { SubmitReportComponent } from './dialogs/report/submit-report/submit-report.component';
import { UpdateStatusComponent } from './dialogs/user/update-status/update-status.component';
import { UpdateJobComponent } from './dialogs/job/update-job/update-job.component';
import { TruncatePipe } from './pipe/truncate.pipe';
import { RoleGuard } from './guard/role.guard';
import { AuthGuard } from './guard/auth.guard';

@NgModule({
  declarations: [
    AppComponent,
    NavBarComponent,
    ErrorComponent,
    LoginPageComponent,
    ProfileComponent,
    ChangePasswordComponent,
    UpdateProfileComponent,
    CompanyAstrioAdminComponent,
    ViewCompanyComponent,
    UpdateCompanyComponent,
    ForgotPasswordComponent,
    ResetPasswordComponent,
    ProjectAstrioAdminComponent,
    UpdateProjectComponent,
    ViewProjectComponent,
    UpdateTicketComponent,
    ViewTicketComponent,
    JobAstrioComponent,
    JobActionAstrioComponent,
    UserAstrioAdminComponent,
    TicketAstrioComponent,
    UpdateActionComponent,
    UpdateUserComponent,
    ViewUserComponent,
    UpdateSkillComponent,
    ViewActionComponent,
    ProjectAstrioUserComponent,
    TicketCompanyComponent,
    ProjectCompanyComponent,
    DashboardCompanyAdminComponent,
    UserCompanyAdminComponent,
    DashboardCompanyUserComponent,
    DashboardAstrioAdminComponent,
    DashboardAstrioUserComponent,
    ContractAstrioAdminComponent,
    ViewContractComponent,
    UpdateContractComponent,
    CloseActionComponent,
    CloseJobComponent,
    TruncatePipe,
    ToastComponent,
    ReportAstrioComponent,
    SubmitReportComponent,
    UpdateStatusComponent,
    UpdateJobComponent,
  ],

  imports: [
    AppRoutingModule,
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    FormsModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    ReactiveFormsModule,
    MatTabsModule,
    MatDialogModule,
    MatFormFieldModule,
    MatSelectModule,
    MatRadioModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatChipsModule,
    MatMomentDateModule,
    NgbModule,
    TableModule,
    SelectButtonModule,
    ToastModule,
    SkeletonModule,
    InputTextModule,
    ProgressBarModule,
    DropdownModule,
  ],
  providers: [
    MatDatepickerModule,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true,
    },
    AuthGuard,
    RoleGuard,
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
