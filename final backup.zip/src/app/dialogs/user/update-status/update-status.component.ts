import { User } from 'src/app/interface/User';
import { StaffService } from 'src/app/service/staff.service';
import { AlertService } from 'src/app/service/alert.service';
import { UserService } from 'src/app/service/user.service';
import { FormControl, FormGroup } from '@angular/forms';
import { Skill } from './../../../interface/Skill';
import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-update-status',
  templateUrl: './update-status.component.html',
  styleUrls: ['./update-status.component.css'],
})
export class UpdateStatusComponent implements OnInit {
  statuses: Skill[];
  statusForm: FormGroup;

  constructor(
    @Inject(MAT_DIALOG_DATA)
    public data: { username: string; currentStatus: string },
    private staffService: StaffService,
    private alertService: AlertService,
    private dialogRef: MatDialogRef<UpdateStatusComponent>
  ) {}

  ngOnInit(): void {
    this.createFormGroup();
    this.getStatus();
  }

  /**
   * create FormGroup with values
   */
  createFormGroup() {
    this.statusForm = new FormGroup({
      status: new FormControl(this.data.currentStatus),
    });
  }

  /**
   * get current skills that users have
   */
  getStatus() {
    this.staffService.getStatus().subscribe({
      next: (res) => {
        this.statuses = res;
      },
      error: (err) => {
        this.alertService.displayError('Unable to retrive status');
      },
    });
  }

  /**
   * validate input
   */
  onSubmit() {
    if (this.statusForm.valid) {
      const user: User = {
        username: this.data.username,
        statusName: this.statusForm.get('status')?.value,
      };
      this.updateStatus(user);
    }
  }

  /**
   * update status of staff
   * @param { User } user updated status
   */
  updateStatus(user: User) {
    this.staffService.updateStatus(user).subscribe({
      next: (res) => {
        this.dialogRef.close();
        this.alertService.displaySuccess('Status updated!');
      },
      error: (err) => {
        this.alertService.displayError('Unable to update status');
      },
    });
  }
}
