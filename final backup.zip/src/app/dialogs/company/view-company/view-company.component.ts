import { ProjectService } from 'src/app/service/project.service';
import { Project } from 'src/app/interface/Project';
import { AlertService } from './../../../service/alert.service';
import { FileService } from './../../../service/file.service';
import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Company } from 'src/app/interface/Company';

@Component({
  selector: 'app-view-company',
  templateUrl: './view-company.component.html',
  styleUrls: ['./view-company.component.css'],
})
export class ViewCompanyComponent implements OnInit {
  hasImage: boolean;
  dataLoaded: Promise<boolean> = Promise.resolve(false);
  image = new Array();
  chips = new Array();

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: Company,
    private fileService: FileService,
    private alertService: AlertService,
    private projectService: ProjectService
  ) {}

  ngOnInit(): void {
    this.getImage();
    this.getCompanyProjectLink();
  }

  /**
   * get project that are linked with the company
   */
  getCompanyProjectLink() {
    this.projectService.getProjectByCompanyName(this.data.name!).subscribe({
      next: (res) => {
        res.forEach((project: Project) => {
          this.chips.push(project.name);
        });
      },
      error: () => {
        this.alertService.displayError('Failed to retrieve company');
      },
    });
  }

  /**
   * get image using image path from database
   */
  getImage() {
    if (this.data.logoPath) {
      this.fileService
        .getFileAsBlob(this.data.name!, this.data.logoPath)
        .subscribe({
          next: (image: Blob) => {
            this.hasImage = true;
            this.blobToImageToDisplay(image);
          },
          error: (err) => {
            this.alertService.displayError('Image not found');
            this.hasImage = false;
            this.dataLoaded = Promise.resolve(true);
          },
        });
    } else {
      this.hasImage = false;
      this.dataLoaded = Promise.resolve(true);
    }
  }

  /**
   * convert blob to image to display
   * @param  {Blob} image image file
   */
  blobToImageToDisplay(image: Blob) {
    let reader = new FileReader();
    reader.addEventListener(
      'load',
      () => {
        this.image.push(reader.result);
      },
      false
    );
    if (image) {
      reader.readAsDataURL(image);
    }
    this.dataLoaded = Promise.resolve(true);
  }
}
