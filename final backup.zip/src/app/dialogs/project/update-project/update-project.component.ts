import { Project } from 'src/app/interface/Project';
import { ProjectService } from 'src/app/service/project.service';
import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { AlertService } from 'src/app/service/alert.service';
import { UpdateCompanyComponent } from '../../company/update-company/update-company.component';

@Component({
  selector: 'app-update-project',
  templateUrl: './update-project.component.html',
  styleUrls: ['./update-project.component.css'],
})
export class UpdateProjectComponent implements OnInit {
  projectForm!: FormGroup;
  type: string = '';

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private projectService: ProjectService,
    private dialogRef: MatDialogRef<UpdateCompanyComponent>,
    private alertService: AlertService
  ) {}

  ngOnInit(): void {
    this.checkMode();
  }

  /**
   * check whether user is creating or updating project
   */
  checkMode() {
    this.type = this.data.type;
    if (this.type == 'Create') {
      this.createMode();
    } else if (this.type == 'Edit') {
      this.editMode();
    }
  }

  /**
   * create FormGroup with values
   */
  createMode() {
    this.projectForm = new FormGroup({
      name: new FormControl(null, Validators.required),
      description: new FormControl(null, Validators.required),
    });
  }

  /**
   * create FormGroup with values
   */
  editMode() {
    this.projectForm = new FormGroup({
      name: new FormControl(this.data.project.name, Validators.required),
      description: new FormControl(
        this.data.project.description,
        Validators.required
      ),
    });
  }

  /**
   * validate form
   */
  onSubmit() {
    if (this.projectForm.valid) {
      const project: Project = {
        name: this.projectForm.get('name')?.value,
        oldName: this.data.project.name,
        description: this.projectForm.get('description')?.value,
      };
      if (this.type == 'Create') {
        this.createProject(project);
      } else if (this.type == 'Edit') {
        this.updateProject(project);
      }
    }
  }

  /**
   * submit project to API
   * @param {Project} project project to be created
   */
  createProject(project: Project) {
    this.projectService.createProject(project).subscribe({
      next: () => {
        this.dialogRef.close();
        this.alertService.displaySuccess('Created project: ' + project.name);
      },
      error: (err) => {
        this.alertService.displayError('Please try again');
      },
    });
  }

  /**
   * submit project to API
   * @param {Project} project project to be updated
   */
  updateProject(project: Project) {
    this.projectService.updateProject(project).subscribe({
      next: () => {
        this.dialogRef.close();
        this.alertService.displaySuccess('Updated project: ' + project.name);
      },
      error: (err) => {
        this.alertService.displayError('Please try again');
      },
    });
  }
}
