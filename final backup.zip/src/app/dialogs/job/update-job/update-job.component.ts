import { Component, Inject, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Skill } from 'src/app/interface/Skill';
import { Ticket } from 'src/app/interface/Ticket';
import { AlertService } from 'src/app/service/alert.service';
import { JobService } from 'src/app/service/job.service';
import { StaffService } from 'src/app/service/staff.service';

@Component({
  selector: 'app-update-job',
  templateUrl: './update-job.component.html',
  styleUrls: ['./update-job.component.css'],
})
export class UpdateJobComponent implements OnInit {
  skills: Skill[];
  skillForm!: FormGroup;
  chips = new Array();

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: Ticket,
    private staffService: StaffService,
    private jobService: JobService,
    private dialogRef: MatDialogRef<UpdateJobComponent>,
    private alertService: AlertService
  ) {}

  ngOnInit(): void {
    this.createFormGroup();
    this.getSkill();
  }

  /**
   * create FormGroup with values
   */
  createFormGroup() {
    this.skillForm = new FormGroup({
      skill: new FormControl(null),
    });
    this.skillForm.get('skill')?.valueChanges.subscribe((skill) => {
      this.addChip(skill);
    });
  }

  /**
   * get skill
   */
  getSkill() {
    this.staffService.getSkill().subscribe({
      next: (res) => {
        this.skills = res;
      },
      error: (err) => {
        this.alertService.displayError('Unable to retrive skill');
      },
    });
  }

  /**
   * add skill to list of chips
   * @param {string} skill skill to be added to chip
   */
  addChip(skill: string) {
    this.chips.push(skill);
  }

  /**
   * remove skill from list of chips
   * @param {string} skill skill to be removed from chip
   */
  removeChip(skill: string) {
    this.chips.forEach((value, index) => {
      if (value == skill) {
        this.chips.splice(index, 1);
      }
    });
  }

  /**
   * check skill from list of chips
   * @param {string} skill skill to be checked from chip
   * @return {boolean} true to disable, false to enable
   */
  checkChip(skill: string): boolean {
    let disable: boolean = false;
    this.chips.forEach((value) => {
      if (value == skill) {
        disable = true;
      }
    });
    return disable;
  }

  /**
   * validate input
   * make an array of all the skills
   */
  onSubmit() {
    if (this.chips.length == 0) {
      this.alertService.displayWarning('Please select skill');
      return;
    }
    let addedSkill: string = '';
    this.chips.forEach((skill) => {
      if (addedSkill == '') {
        addedSkill = skill;
      } else {
        addedSkill = addedSkill + ';' + skill;
      }
    });
    const ticket: Ticket = {
      ticketId: this.data.id,
      ticketSkill: addedSkill,
    };
    this.createJob(ticket);
  }

  /**
   * acknowledge ticket and create job with preset skills
   * @param {Ticket} ticket ticket to be acknowledged
   */
  createJob(ticket: Ticket) {
    this.jobService.createJob(ticket).subscribe({
      next: () => {
        this.alertService.displaySuccess(
          'Job started for ticket: ' + ticket.title
        );
        this.dialogRef.close(); // if valid and complete den close
      },
      error: (err) => {
        this.alertService.displayError('Please try again');
      },
    });
  }
}
