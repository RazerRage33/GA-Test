import { HttpErrorResponse } from '@angular/common/http';
import { Job } from 'src/app/interface/Job';
import { JobService } from 'src/app/service/job.service';
import { Component, Inject, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { AlertService } from 'src/app/service/alert.service';
import { CustomErrorStateMatcher } from 'src/app/CustomErrorStateMatcher';

@Component({
  selector: 'app-close-action',
  templateUrl: './close-action.component.html',
  styleUrls: ['./close-action.component.css'],
})
export class CloseActionComponent implements OnInit {
  matcher = new CustomErrorStateMatcher();
  actionForm!: FormGroup;
  type: string = '';

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: { jobId: string; type: string },
    private jobService: JobService,
    private dialogRef: MatDialogRef<CloseActionComponent>,
    private alertService: AlertService
  ) {}

  ngOnInit(): void {
    this.createFormGroup();
    if (this.data.type == 'close') {
      this.type = 'Close job action';
    } else if (this.data.type == 'update') {
      this.type = 'Update manhours';
    }
  }

  /**
   * create FormGroup with no values
   */
  createFormGroup() {
    this.actionForm = new FormGroup({
      manHoursUsed: new FormControl(null, [
        Validators.pattern('^[0-9]*$'),
        Validators.required,
      ]),
    });
  }

  /**
   * validate form
   */
  onSubmit() {
    let manhours: string = this.actionForm.get('manHoursUsed')?.value;
    if (manhours == '0') {
      this.alertService.displayWarning('Manhours cannot be 0');
      return;
    }
    if (this.actionForm.valid) {
      const job: Job = {
        id: this.data.jobId,
        manHoursUsed: manhours,
      };
      if (this.data.type == 'close') {
        this.closeAction(job);
      } else if (this.data.type == 'update') {
        this.updateAction(job);
      }
    }
  }

  /**
   * submit job action to close to API
   * @param {Job} job job action to be closed
   */
  closeAction(job: Job) {
    this.jobService.closeJobAction(job).subscribe({
      next: () => {
        this.dialogRef.close();
        this.alertService.displaySuccess('Closed job action');
      },
      error: (err: HttpErrorResponse) => {
        this.alertService.displayError('Failed to close job action');
      },
    });
  }

  /**
   * submit job action to update manhours to API
   * @param {Job} job job action to be updated
   */
  updateAction(job: Job) {
    this.jobService.updateManhours(job).subscribe({
      next: () => {
        this.dialogRef.close();
        this.alertService.displaySuccess('Updated manhours of job action');
      },
      error: (err: HttpErrorResponse) => {
        this.alertService.displayError('Failed to update job action');
      },
    });
  }
}
