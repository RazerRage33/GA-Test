import { CompanyService } from 'src/app/service/company.service';
import { DateService } from './../../../service/date.service';
import { ContractService } from './../../../service/contract.service';
import { AlertService } from 'src/app/service/alert.service';
import { ProjectService } from 'src/app/service/project.service';
import { Project } from 'src/app/interface/Project';
import { Contract } from 'src/app/interface/Contract';
import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CustomErrorStateMatcher } from 'src/app/CustomErrorStateMatcher';

@Component({
  selector: 'app-update-contract',
  templateUrl: './update-contract.component.html',
  styleUrls: ['./update-contract.component.css'],
})
export class UpdateContractComponent implements OnInit {
  matcher = new CustomErrorStateMatcher();
  types: Contract[];
  projects: Project[];
  contractForm!: FormGroup;

  constructor(
    @Inject(MAT_DIALOG_DATA)
    public data: { companyName: string; currentContract: Contract[] },
    private dialogRef: MatDialogRef<UpdateContractComponent>,
    private projectService: ProjectService,
    private alertService: AlertService,
    private contractService: ContractService,
    private companyService: CompanyService,
    private dateService: DateService
  ) {}

  ngOnInit(): void {
    this.getType();
    this.getProject();
    this.createFormGroup();
  }

  /**
   * create FormGroup with no values
   */
  createFormGroup() {
    this.contractForm = new FormGroup({
      project: new FormControl(null, Validators.required),
      type: new FormControl(null, Validators.required),
      totalManhours: new FormControl(null, [
        Validators.pattern('^[0-9]*$'),
        Validators.required,
      ]),
      description: new FormControl(null, Validators.required),
      startDate: new FormControl(
        { value: null, disabled: true },
        Validators.required
      ),
      endDate: new FormControl(
        { value: null, disabled: true },
        Validators.required
      ),
    });
  }

  /**
   * get contract types available
   */
  getType() {
    this.contractService.getContractType().subscribe({
      next: (res) => {
        this.types = res;
      },
      error: (err) => {
        this.alertService.displayError('Failed to get types.');
      },
    });
  }

  /**
   * get project to display in table
   */
  getProject() {
    this.projectService.getProject().subscribe({
      next: (res) => {
        this.projects = res;
      },
      error: (err) => {
        this.alertService.displayError('Failed to get projects');
      },
    });
  }

  /**
   * validate form
   */
  onSubmit() {
    if (this.contractForm.valid) {
      const contract: Contract = {
        companyName: this.data.companyName,
        projectId: this.contractForm.get('project')?.value.projectId,
        projectName: this.contractForm.get('project')?.value.projectName,
        typeName: this.contractForm.get('type')?.value,
        manhoursTotal: this.contractForm.get('totalManhours')?.value,
        details: this.contractForm.get('description')?.value,
        startDate: this.dateService.transformDate(
          this.contractForm.get('startDate')?.value
        ),
        endDate: this.dateService.transformDate(
          this.contractForm.get('endDate')?.value
        ),
      };
      this.createContract(contract);
    }
  }

  /**
   * submit contract to API
   * @param  {Contract} contract contract to be submitted
   */
  createContract(contract: Contract) {
    this.contractService.createContract(contract).subscribe({
      next: () => {
        this.linkToCompany(contract.projectName!);
      },
      error: (err) => {
        this.alertService.displayError('Please fill in the requied fields');
      },
    });
  }

  /**
   * submit contract and company to API
   * @param { string } projectName project contract to be added to current list of contracts
   */
  linkToCompany(projectName: string) {
    let projects: Project[] = [];
    this.data.currentContract.forEach((contract) => {
      projects.push({
        companyName: this.data.companyName,
        projectName: contract.projectName,
      });
    });
    projects.push({
      companyName: this.data.companyName,
      projectName: projectName,
    });
    this.companyService.linkCompanyWithProject(projects).subscribe({
      next: () => {
        this.alertService.displaySuccess('Contract successfully created');
        this.dialogRef.close();
      },
      error: (err) => {
        this.alertService.displayError('Please try again');
      },
    });
  }
}
