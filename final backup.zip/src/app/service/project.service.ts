import { Project } from './../interface/Project';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API_URL, HTTP_OPTION } from '../APP_CONFIG';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ProjectService {
  constructor(private http: HttpClient) {}

  /**
   * get all project from database
   * @return {Project[]}  all project
   */
  getProject(): Observable<Project[]> {
    return this.http.get<Project[]>(API_URL + 'Project/All', HTTP_OPTION);
  }

  /**
   * get project by company from database
   * @return {Project[]}  all project
   */
  getProjectByCompany(): Observable<Project[]> {
    return this.http.get<Project[]>(
      API_URL + 'Project/GetProjectsByCompany',
      HTTP_OPTION
    );
  }

  /**
   * get projects that are linked to the given company
   * @param {string} company company name to be queried
   * @return {Project[]}  all project
   */
  getProjectByCompanyName(company: string): Observable<Project[]> {
    return this.http.get<Project[]>(
      API_URL + 'Project/GetProjectsByCompany/' + company,
      HTTP_OPTION
    );
  }

  /**
   * get projects that are linked to the given user'company
   * @return {Project[]}  all project
   */
  getProjectByUser(): Observable<Project[]> {
    return this.http.get<Project[]>(
      API_URL + 'Project/GetProjectsByCompany',
      HTTP_OPTION
    );
  }

  /**
   * send project to api to create
   * @param {Project} project project to be created
   */
  createProject(project: Project) {
    return this.http.post<Project[]>(
      API_URL + 'Project/Create',
      project,
      HTTP_OPTION
    );
  }

  /**
   * send project to api to update
   * @param {Project} project project to be updated
   */
  updateProject(project: Project) {
    return this.http.post<Project[]>(
      API_URL + 'Project/Update',
      project,
      HTTP_OPTION
    );
  }
}
