import { Injectable } from '@angular/core';
import * as moment from 'moment';

@Injectable({
  providedIn: 'root',
})
export class DateService {
  constructor() {}

  transformDate(date: string) {
    return moment(date).format('YYYY-MM-DD HH:mm:ss');
  }
}
