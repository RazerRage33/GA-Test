import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { API_URL, HTTP_OPTION } from '../APP_CONFIG';
import { Contract } from '../interface/Contract';
import { Dashboard } from '../interface/Dashboard';
import { Job } from '../interface/Job';
import { Ticket } from '../interface/Ticket';
import { User } from '../interface/User';

@Injectable({
  providedIn: 'root',
})
export class DashboardService {
  constructor(private http: HttpClient) {}

  /**
   * get dashboard info from database
   * @return {User[]}  all project
   */
  getDashboardInfo(): Observable<Dashboard> {
    return this.http.get<Dashboard>(API_URL + 'Dashboard', HTTP_OPTION);
  }

  /**
   * get lastest 5 job action from database
   * @return {Job[]}  lastest 5 job action
   */
  getJobAction(): Observable<Job[]> {
    return this.http.get<Job[]>(
      API_URL + 'Dashboard/GetMyJobActionForDashboard',
      HTTP_OPTION
    );
  }

  /**
   * get ticket from API
   * @return {any}  ticket observable
   */
  getTicket(): Observable<Ticket[]> {
    return this.http.get<Ticket[]>(
      API_URL + 'Dashboard/GetTicketForDashboard',
      HTTP_OPTION
    );
  }

  /**
   * get client's ticket from API
   * @return {any}  ticket observable
   */
  getTicketClient(): Observable<Ticket[]> {
    return this.http.get<Ticket[]>(
      API_URL + 'Dashboard/GetTicketForClientDashboard',
      HTTP_OPTION
    );
  }

  /**
   * get client's contracts from API
   * @return {any}  ticket observable
   */
  getContractClient(): Observable<Contract[]> {
    return this.http.get<Contract[]>(
      API_URL + 'Dashboard/GetContractForClientDashboard',
      HTTP_OPTION
    );
  }

  /**
   * get all available users from database
   * @return {User[]}  all project
   */
  getUser(): Observable<User[]> {
    return this.http.get<User[]>(
      API_URL + 'Dashboard/GetAvailableStaffForDashboard',
      HTTP_OPTION
    );
  }
}
