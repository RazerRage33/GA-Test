import { Skill } from './../interface/Skill';
import { Job } from './../interface/Job';
import { User } from './../interface/User';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { API_URL, HTTP_OPTION } from '../APP_CONFIG';

@Injectable({
  providedIn: 'root',
})
export class StaffService {
  constructor(private http: HttpClient) {}

  /**
   * get all staff name from database
   * @return {User[]}  all project
   */
  getStaffName(): Observable<Job[]> {
    return this.http.get<Job[]>(
      API_URL + 'Staff/GetAllStaffUsername',
      HTTP_OPTION
    );
  }

  /**
   * get all staff from database
   * @param {string} role role queried
   * @return {User[]}  all project
   */
  getStaff(role: string): Observable<User[]> {
    return this.http.get<User[]>(
      API_URL + 'Staff/GetAllStaffInformationByRole/' + role,
      HTTP_OPTION
    );
  }

  /**
   * get all skill from database
   * @return {Skill[]} all skill
   */
  getSkill(): Observable<Skill[]> {
    return this.http.get<Skill[]>(API_URL + 'Staff/Skill', HTTP_OPTION);
  }

  /**
   * get skill by user from database
   * @param {string} username skill of user
   * @return {Skill[]} skill by user
   */
  getSkillByUser(username: string): Observable<Skill[]> {
    return this.http.get<Skill[]>(
      API_URL + 'Staff/GetStaffSkillByUsername/' + username,
      HTTP_OPTION
    );
  }

  /**
   * add skills for user
   * @param {Skill[]} skill skill of user
   * @return {any} response
   */
  addSkill(skill: Skill[]) {
    return this.http.post<Skill[]>(
      API_URL + 'Staff/AddStaffSkill',
      skill,
      HTTP_OPTION
    );
  }

  /**
   * get user status request to API
   * @return {any}  status
   */
  getStatus(): Observable<Skill[]> {
    return this.http.get<Skill[]>(API_URL + 'Staff/StaffStatus', HTTP_OPTION);
  }

  /**
   * update user status
   * @param { User } user status to be updated
   * @return {any} response
   */
  updateStatus(user: User): Observable<User[]> {
    return this.http.post<User[]>(
      API_URL + 'Staff/UpdateStaffStatus',
      user,
      HTTP_OPTION
    );
  }
}
