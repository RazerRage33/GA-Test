import { Report } from './../interface/Report';
import { Job } from 'src/app/interface/Job';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { API_URL, HTTP_OPTION } from '../APP_CONFIG';

@Injectable({
  providedIn: 'root',
})
export class ReportService {
  constructor(private http: HttpClient) {}

  /**
   * get report from database
   * @param { string } ticketId report of ticket
   * @return {Report[]}  report
   */
  getReport(ticketId: string): Observable<Report> {
    return this.http.get<Report>(API_URL + 'Report/' + ticketId, HTTP_OPTION);
  }

  /**
   * upload report with signature to database
   * @param { FormData } formData report of ticket with signature
   * @return {Job[]} response
   */
  uploadReport(formData: FormData): Observable<Job[]> {
    return this.http.post<Job[]>(
      API_URL + 'Report/UploadingReport',
      formData,
      HTTP_OPTION
    );
  }
}
