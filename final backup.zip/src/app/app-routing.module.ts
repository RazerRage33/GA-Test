import { ReportAstrioComponent } from './components/astrio/shared/report-astrio/report-astrio.component';
import { ContractAstrioAdminComponent } from './components/astrio/admin/contract-astrio-admin/contract-astrio-admin.component';
import { DashboardAstrioUserComponent } from './components/astrio/user/dashboard-astrio-user/dashboard-astrio-user.component';
import { DashboardAstrioAdminComponent } from './components/astrio/admin/dashboard-astrio-admin/dashboard-astrio-admin.component';
import { DashboardCompanyUserComponent } from './components/company/user/dashboard-company-user/dashboard-company-user.component';
import { DashboardCompanyAdminComponent } from './components/company/admin/dashboard-company-admin/dashboard-company-admin.component';
import { UserCompanyAdminComponent } from './components/company/admin/user-company-admin/user-company-admin.component';
import { TicketCompanyComponent } from './components/company/shared/ticket-company/ticket-company.component';
import { ProjectCompanyComponent } from './components/company/shared/project-company/project-company.component';
import { ProjectAstrioUserComponent } from './components/astrio/user/project-astrio-user/project-astrio-user.component';
import { RoleGuard } from './guard/role.guard';
import { UserAstrioAdminComponent } from './components/astrio/admin/user-astrio-admin/user-astrio-admin.component';
import { JobActionAstrioComponent } from './components/astrio/shared/job-action-astrio/job-action-astrio.component';
import { JobAstrioComponent } from './components/astrio/shared/job-astrio/job-astrio.component';
import { TicketAstrioComponent } from './components/astrio/shared/ticket-astrio/ticket-astrio.component';
import { ProjectAstrioAdminComponent } from './components/astrio/admin/project-astrio-admin/project-astrio-admin.component';
import { ROUTE } from './APP_CONFIG';
import { ResetPasswordComponent } from './components/shared/reset-password/reset-password.component';
import { ForgotPasswordComponent } from './components/shared/forgot-password/forgot-password.component';
import { CompanyAstrioAdminComponent } from './components/astrio/admin/company-astrio-admin/company-astrio-admin.component';
import { ProfileComponent } from './components/shared/profile/profile.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ErrorComponent } from './components/shared/error/error.component';
import { LoginPageComponent } from './components/shared/login/login.component';
import { AuthGuard } from './guard/auth.guard';

const routes: Routes = [
  { path: ROUTE.LOGIN, title: 'Login', component: LoginPageComponent },
  {
    path: ROUTE.FORGOT_PASSWORD,
    title: 'Forgot password',
    component: ForgotPasswordComponent,
  },
  {
    path: ROUTE.RESET_PASSWORD,
    title: 'Reset password',
    component: ResetPasswordComponent,
  },

  {
    path: ROUTE.PROFILE,
    title: 'Profile',
    component: ProfileComponent,
    canActivate: [AuthGuard],
  },
  {
    path: 'astrio',
    title: 'ASTrio',
    canActivate: [AuthGuard, RoleGuard],
    children: [
      {
        path: ROUTE.TICKET,
        title: 'Ticket',
        component: TicketAstrioComponent,
        canActivate: [AuthGuard, RoleGuard],
      },
      {
        path: ROUTE.JOB,
        title: 'Job',
        component: JobAstrioComponent,
        canActivate: [AuthGuard, RoleGuard],
      },
      {
        path: ROUTE.JOB_ACTION,
        title: 'Job action',
        component: JobActionAstrioComponent,
        canActivate: [AuthGuard, RoleGuard],
      },
      {
        path: ROUTE.REPORT,
        title: 'Report',
        component: ReportAstrioComponent,
        canActivate: [AuthGuard, RoleGuard],
      },
      {
        path: 'user',
        title: 'ASTrio user',
        children: [
          {
            path: ROUTE.DASHBOARD,
            title: 'Home',
            component: DashboardAstrioUserComponent,
            canActivate: [AuthGuard, RoleGuard],
          },
          {
            path: ROUTE.PROJECT,
            title: 'Project',
            component: ProjectAstrioUserComponent,
            canActivate: [AuthGuard, RoleGuard],
          },
        ],
      },
      {
        path: 'admin',
        title: 'ASTrio admin',
        children: [
          {
            path: ROUTE.DASHBOARD,
            title: 'Home',
            component: DashboardAstrioAdminComponent,
            canActivate: [AuthGuard, RoleGuard],
          },
          {
            path: ROUTE.COMPANY,
            title: 'Company',
            component: CompanyAstrioAdminComponent,
            canActivate: [AuthGuard, RoleGuard],
          },
          {
            path: ROUTE.CONTRACT,
            title: 'Contract',
            component: ContractAstrioAdminComponent,
            canActivate: [AuthGuard, RoleGuard],
          },
          {
            path: ROUTE.PROJECT,
            title: 'Project',
            component: ProjectAstrioAdminComponent,
            canActivate: [AuthGuard, RoleGuard],
          },
          {
            path: ROUTE.USER,
            title: 'User',
            component: UserAstrioAdminComponent,

            canActivate: [AuthGuard, RoleGuard],
          },
        ],
      },
    ],
  },

  {
    path: 'company',
    title: 'Company',
    canActivate: [AuthGuard],
    children: [
      {
        path: ROUTE.PROJECT,
        title: 'Project',
        component: ProjectCompanyComponent,
        canActivate: [AuthGuard, RoleGuard],
      },
      {
        path: ROUTE.TICKET,
        title: 'Ticket',
        component: TicketCompanyComponent,
        canActivate: [AuthGuard, RoleGuard],
      },
      {
        path: 'admin',
        title: 'admin',
        canActivate: [AuthGuard],
        children: [
          {
            path: ROUTE.DASHBOARD,
            title: 'Home',
            component: DashboardCompanyAdminComponent,
            canActivate: [AuthGuard, RoleGuard],
          },
          {
            path: ROUTE.USER,
            title: 'User',
            component: UserCompanyAdminComponent,
            canActivate: [AuthGuard, RoleGuard],
          },
        ],
      },
      {
        path: 'user',
        title: 'Company user',
        canActivate: [AuthGuard],
        children: [
          {
            path: ROUTE.DASHBOARD,
            title: 'Home',
            component: DashboardCompanyUserComponent,
            canActivate: [AuthGuard, RoleGuard],
          },
        ],
      },
    ],
  },
  { path: '**', title: '404 Error', component: ErrorComponent }, //wildcard route; will come here if invalid link
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      enableTracing: true,
      onSameUrlNavigation: 'reload',
    }),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}
