import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ROUTE } from 'src/app/APP_CONFIG';
import { ViewTicketComponent } from 'src/app/dialogs/ticket/view-ticket/view-ticket.component';
import { Dashboard } from 'src/app/interface/Dashboard';
import { Ticket } from 'src/app/interface/Ticket';
import { User } from 'src/app/interface/User';
import { AlertService } from 'src/app/service/alert.service';
import { DashboardService } from 'src/app/service/dashboard.service';
import { FileService } from 'src/app/service/file.service';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-dashboard-company-user',
  templateUrl: './dashboard-company-user.component.html',
  styleUrls: ['./dashboard-company-user.component.css'],
})
export class DashboardCompanyUserComponent implements OnInit {
  user: User;

  tickets!: Ticket[];
  dashboardInfo: Dashboard;
  loadingTicket: boolean = true;

  filterColumnTicket: string[] = [
    'title',
    'projectName',
    'categoryName',
    'requestedOn',
    'statusName',
  ];

  dataLoadedProfile: Promise<boolean> = Promise.resolve(false);
  dataLoadedDashboard: Promise<boolean> = Promise.resolve(false);

  constructor(
    private userService: UserService,
    private alertService: AlertService,
    private dialog: MatDialog,
    private dashboardService: DashboardService,
    private fileService: FileService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.getProfile();
    this.getDashboardInfo();
    this.getTicket();
  }

  /**
   * get profile information
   */
  getProfile() {
    this.userService.getProfile().subscribe({
      next: (res) => {
        this.user = res;
        this.dataLoadedProfile = Promise.resolve(true);
      },
      error: (err) => {
        this.alertService.displayError('Failed to get profile');
      },
    });
  }

  /**
   * get dashboard information
   */
  getDashboardInfo() {
    this.dashboardService.getDashboardInfo().subscribe({
      next: (res) => {
        this.dashboardInfo = res;
        this.dataLoadedDashboard = Promise.resolve(true);
      },
      error: (err) => {
        this.alertService.displayError('Failed to get dashboard information');
      },
    });
  }

  /**
   * get ticket to display in table
   */
  getTicket() {
    this.loadingTicket = true;
    this.dashboardService.getTicketClient().subscribe({
      next: (res) => {
        this.loadingTicket = false;
        this.tickets = res;
      },
      error: (err) => {
        this.alertService.displayError('Failed to get tickets');
      },
    });
  }

  /**
   * open dialog to view ticket
   */
  onViewTicket(ticket: Ticket) {
    this.dialog.open(ViewTicketComponent, { data: ticket });
  }

  /**
   * get file using file path from database
   */
  onDownloadReport(row: Ticket) {
    if (row.reportPath) {
      this.fileService
        .getFileAsBlob(row.companyName!, row.reportPath)
        .subscribe({
          next: (res) => {
            let FileSaver = require('file-saver');
            FileSaver.saveAs(res, row.reportPath);
          },
          error: (err) => {
            this.alertService.displayError('Failed to download report');
          },
        });
    }
  }

  /**
   * go to profile page
   */
  routeToProfile() {
    this.router.navigate([ROUTE.PROFILE]);
  }
}
