import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Table } from 'primeng/table';
import { ViewContractComponent } from 'src/app/dialogs/contract/view-contract/view-contract.component';
import { Contract } from 'src/app/interface/Contract';
import { AlertService } from 'src/app/service/alert.service';
import { DashboardService } from 'src/app/service/dashboard.service';

@Component({
  selector: 'app-project-company',
  templateUrl: './project-company.component.html',
  styleUrls: ['./project-company.component.css'],
})
export class ProjectCompanyComponent implements OnInit {
  @ViewChild('dt') dt: Table | undefined;
  loading: boolean = true;
  contracts!: Contract[];
  filterColumn: string[] = ['name', 'createdOn', 'updatedOn'];

  constructor(
    private dialog: MatDialog,
    private alertService: AlertService,
    private dashboardService: DashboardService
  ) {}

  ngOnInit(): void {
    this.getContract();
  }

  /**
   * get contract to display in table
   */
  getContract() {
    this.loading = true;
    this.dashboardService.getContractClient().subscribe({
      next: (res) => {
        this.loading = false;
        this.contracts = res;
      },
      error: (err) => {
        this.alertService.displayError('Failed to get tickets');
      },
    });
  }

  /**
   * filter search
   */
  applyFilter($event: any, stringVal: string) {
    this.dt!.filterGlobal(($event.target as HTMLInputElement).value, stringVal);
  }

  /**
   * open page to view project with contract
   */
  onViewProject(project: Contract) {
    this.dialog.open(ViewContractComponent, { data: project });
  }
}
