import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { Table } from 'primeng/table';
import { ROUTE } from 'src/app/APP_CONFIG';
import { CloseActionComponent } from 'src/app/dialogs/job/close-action/close-action.component';
import { ViewActionComponent } from 'src/app/dialogs/job/view-action/view-action.component';
import { ViewTicketComponent } from 'src/app/dialogs/ticket/view-ticket/view-ticket.component';
import { UpdateSkillComponent } from 'src/app/dialogs/user/update-skill/update-skill.component';
import { UpdateStatusComponent } from 'src/app/dialogs/user/update-status/update-status.component';
import { ViewUserComponent } from 'src/app/dialogs/user/view-user/view-user.component';
import { Dashboard } from 'src/app/interface/Dashboard';
import { Job } from 'src/app/interface/Job';
import { Ticket } from 'src/app/interface/Ticket';
import { User } from 'src/app/interface/User';
import { AlertService } from 'src/app/service/alert.service';
import { DashboardService } from 'src/app/service/dashboard.service';
import { JobService } from 'src/app/service/job.service';
import { TicketService } from 'src/app/service/ticket.service';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-dashboard-astrio-admin',
  templateUrl: './dashboard-astrio-admin.component.html',
  styleUrls: ['./dashboard-astrio-admin.component.css'],
})
export class DashboardAstrioAdminComponent implements OnInit {
  @ViewChild('dtUser') dtUser: Table | undefined;

  user: User;
  jobActions!: Job[];
  tickets!: Ticket[];
  users: User[];
  dashboardInfo: Dashboard;

  loadingJobAction: boolean = true;
  loadingTicket: boolean = true;
  loadingUser: boolean = true;

  filterColumnJobAction: string[] = ['staffName', 'description', 'createdBy'];
  filterColumnTicket: string[] = [
    'title',
    'projectName',
    'categoryName',
    'requestedOn',
    'statusName',
  ];
  filterColumnUser: string[] = [
    'username',
    'email',
    'phoneNumber',
    'workload',
    'statusName',
  ];

  dataLoadedProfile: Promise<boolean> = Promise.resolve(false);
  dataLoadedDashboard: Promise<boolean> = Promise.resolve(false);

  constructor(
    private userService: UserService,
    private alertService: AlertService,
    private dialog: MatDialog,
    private dashboardService: DashboardService,
    private jobService: JobService,
    private ticketService: TicketService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.getProfile();
    this.getDashboardInfo();
    this.getJobAction();
    this.getTicket();
    this.getUser();
  }

  /**
   * filter search
   */
  applyFilter($event: any, stringVal: string) {
    this.dtUser!.filterGlobal(
      ($event.target as HTMLInputElement).value,
      stringVal
    );
  }

  /**
   * get profile information
   */
  getProfile() {
    this.userService.getProfile().subscribe({
      next: (res) => {
        this.user = res;
        this.dataLoadedProfile = Promise.resolve(true);
      },
      error: (err) => {
        this.alertService.displayError('Failed to get profile');
      },
    });
  }

  /**
   * get dashboard information
   */
  getDashboardInfo() {
    this.dashboardService.getDashboardInfo().subscribe({
      next: (res) => {
        this.dashboardInfo = res;
        this.dataLoadedDashboard = Promise.resolve(true);
      },
      error: (err) => {
        this.alertService.displayError('Failed to get dashboard information');
      },
    });
  }

  /**
   * open dialog to update status
   */
  onUpdateStatus() {
    let dialogRef = this.dialog.open(UpdateStatusComponent, {
      data: { username: this.user.username, currentStatus: this.user.status },
    });
    dialogRef.afterClosed().subscribe(() => {
      this.getProfile();
    });
  }

  /**
   * get latest 5 job actions to display in table
   */
  getJobAction() {
    this.loadingJobAction = true;
    this.dashboardService.getJobAction().subscribe({
      next: (res) => {
        this.loadingJobAction = false;
        this.jobActions = res;
      },
      error: (err) => {
        this.alertService.displayError('Failed to get job actions');
      },
    });
  }

  /**
   * open page to view job action
   */
  onViewJobAction(job: Job) {
    this.dialog.open(ViewActionComponent, { data: job });
  }

  /**
   * open dialog to close job action
   */
  onCloseJobAction(job: Job) {
    let dialogRef = this.dialog.open(CloseActionComponent, { data: job.id });
    dialogRef.afterClosed().subscribe(() => {
      this.getJobAction();
    });
  }

  /**
   * get ticket to display in table
   */
  getTicket() {
    this.loadingTicket = true;
    this.dashboardService.getTicket().subscribe({
      next: (res) => {
        this.loadingTicket = false;
        this.tickets = res;
      },
      error: (err) => {
        this.alertService.displayError('Failed to get tickets');
      },
    });
  }

  /**
   * open dialog to view ticket
   * at the same time, update ticket status to 'processed'
   */
  onViewTicket(ticket: Ticket) {
    this.ticketService.processTicket(ticket).subscribe({
      next: () => {
        this.getTicket();
        this.dialog.open(ViewTicketComponent, { data: ticket });
      },
      error: (err) => {
        this.alertService.displayError('Please try again');
      },
    });
  }

  /**
   * acknowledge ticket and create job
   * @param {Ticket} ticket ticket to be acknowledged
   */
  onCreateJob(ticket: Ticket) {
    this.jobService.createJob(ticket).subscribe({
      next: () => {
        this.alertService.displaySuccess(
          'Job started for ticket: ' + ticket.title
        );
        this.getTicket();
      },
      error: (err) => {
        this.alertService.displayError('Please try again');
      },
    });
  }

  /**
   * get staff (astrio members) to fill table
   */
  getUser() {
    this.loadingUser = true;
    this.dashboardService.getUser().subscribe({
      next: (res) => {
        this.users = res;
        this.loadingUser = false;
      },
      error: (err) => {
        this.alertService.displayError('Failed to get users');
      },
    });
  }

  /**
   * open dialog to view user
   */
  onViewUser(user: User) {
    this.dialog.open(ViewUserComponent, { data: user });
  }

  /**
   * open dialog to edit skill
   */
  onAddSkill(user: User) {
    this.dialog.open(UpdateSkillComponent, { data: user });
  }

  /**
   * open dialog to update status
   * only for staff
   * @param { User } user user to be updated
   */
  onUpdateUserStatus(user: User) {
    let dialogRef = this.dialog.open(UpdateStatusComponent, {
      data: { username: user.username, currentStatus: user.statusName },
    });
    dialogRef.afterClosed().subscribe(() => {
      this.getUser();
    });
  }

  /**
   * go to profile page
   */
  routeToProfile() {
    this.router.navigate([ROUTE.PROFILE]);
  }
}
