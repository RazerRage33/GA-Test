import { ROUTE } from 'src/app/APP_CONFIG';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertService } from '../../../../service/alert.service';
import { ViewCompanyComponent } from '../../../../dialogs/company/view-company/view-company.component';
import { UpdateCompanyComponent } from '../../../../dialogs/company/update-company/update-company.component';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Table } from 'primeng/table';
import { Company } from 'src/app/interface/Company';
import { CompanyService } from 'src/app/service/company.service';
import { Contract } from 'src/app/interface/Contract';

@Component({
  selector: 'app-company-astrio-admin',
  templateUrl: './company-astrio-admin.component.html',
  styleUrls: ['./company-astrio-admin.component.css'],
})
export class CompanyAstrioAdminComponent implements OnInit {
  filterColumn: string[] = ['name', 'totalCount'];
  @ViewChild('dt') dt: Table | undefined;
  loading: boolean = true;
  companies!: Company[] & Contract[];

  constructor(
    private companyService: CompanyService,
    private dialog: MatDialog,
    private alertService: AlertService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.getCompany();
  }

  /**
   * get company to display in table
   */
  getCompany() {
    this.loading = true;
    this.companyService.getCompany().subscribe({
      next: (res: Company[] & Contract[]) => {
        this.loading = false;
        this.companies = res;
      },
      error: (err) => {
        this.alertService.displayError('Failed to get company');
      },
    });
  }

  /**
   * filter search
   */
  applyFilter($event: any, stringVal: string) {
    this.dt!.filterGlobal(($event.target as HTMLInputElement).value, stringVal);
  }

  /**
   * open dialog to view company
   */
  onViewCompany(company: Company) {
    this.dialog.open(ViewCompanyComponent, { data: company });
  }

  /**
   * open dialog to create company
   */
  onCreateCompany() {
    let dialogRef = this.dialog.open(UpdateCompanyComponent, {
      data: {
        type: 'Create',
      },
    });
    dialogRef.afterClosed().subscribe(() => {
      this.getCompany();
    });
  }

  /**
   * open dialog to update company
   */
  onUpdateCompany(company: Company) {
    let dialogRef = this.dialog.open(UpdateCompanyComponent, {
      data: {
        type: 'Edit',
        company,
      },
    });
    dialogRef.afterClosed().subscribe(() => {
      this.getCompany();
    });
  }

  /**
   * open page to update projects for selected compant
   */
  onUpdateProject(company: Company) {
    this.router.navigate(['../' + ROUTE.CONTRACT], {
      relativeTo: this.route,
      queryParams: { name: company.name },
    });
  }
}
