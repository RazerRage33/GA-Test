import { UpdateStatusComponent } from './../../../../dialogs/user/update-status/update-status.component';
import { FormControl, FormGroup } from '@angular/forms';
import { Component, OnInit, ViewChild } from '@angular/core';
import { Table } from 'primeng/table';
import { MatTabChangeEvent } from '@angular/material/tabs';
import { MatDialog } from '@angular/material/dialog';
import { UpdateSkillComponent } from 'src/app/dialogs/user/update-skill/update-skill.component';
import { UpdateUserComponent } from 'src/app/dialogs/user/update-user/update-user.component';
import { ViewUserComponent } from 'src/app/dialogs/user/view-user/view-user.component';
import { Company } from 'src/app/interface/Company';
import { User } from 'src/app/interface/User';
import { AlertService } from 'src/app/service/alert.service';
import { CompanyService } from 'src/app/service/company.service';
import { StaffService } from 'src/app/service/staff.service';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-user-astrio-admin',
  templateUrl: './user-astrio-admin.component.html',
  styleUrls: ['./user-astrio-admin.component.css'],
})
export class UserAstrioAdminComponent implements OnInit {
  roles: string[] = ['User', 'Admin'];
  loading: boolean = true;

  // staff section
  staffUsers: User[];
  staffForm: FormGroup;
  @ViewChild('dtStaff') dtStaff: Table | undefined;
  filterStaffColumn: string[] = [
    'username',
    'email',
    'phoneNumber',
    'statusName',
  ];

  // company section
  companies: Company[];
  companyUsers: User[];
  companyForm: FormGroup;
  @ViewChild('dtCompany') dtCompany: Table | undefined;
  filterCompanyColumn: string[] = [
    'username',
    'email',
    'phoneNumber',
    'workload',
    'statusName',
  ];

  /**
   * tab group
   * index 0 refers to astrio staff tab
   * index 1 refers to company staff tab
   */
  selectedTabIndex: number = 0;
  createUserButton: string = 'Create ASTrio user';

  constructor(
    private staffService: StaffService,
    private alertService: AlertService,
    private companyService: CompanyService,
    private userService: UserService,
    private dialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.getCompany();
    this.createFormGroup();
    this.getStaffUser();
    this.getCompanyUser();
  }

  /**
   * check which tab the page is at
   * index 0 refers to astrio staff tab
   * index 1 refers to company staff tab
   */
  onTabChanged(tabChangeEvent: MatTabChangeEvent): void {
    this.selectedTabIndex = tabChangeEvent.index;
    if (this.selectedTabIndex == 0) {
      this.createUserButton = 'Create ASTrio user';
    } else if (this.selectedTabIndex == 1) {
      this.createUserButton = 'Create company user';
    }
  }

  /**
   * get companies for dropdown
   */
  getCompany() {
    this.companyService.getCompany().subscribe({
      next: (res: Company[]) => {
        this.companies = res;
      },
      error: (err) => {
        this.alertService.displayError('Failed to get company');
      },
    });
  }

  /**
   * create FormGroup. one for staff, one for company
   */
  createFormGroup() {
    this.staffForm = new FormGroup({
      staffRole: new FormControl(this.roles[0]),
    });

    this.companyForm = new FormGroup({
      companyRole: new FormControl(this.roles[0]),
      companyName: new FormControl(),
    });

    this.staffForm.valueChanges.subscribe((res) => {
      this.getStaffUser();
    });

    this.companyForm.valueChanges.subscribe((res) => {
      this.getCompanyUser();
    });
  }

  /**
   * filter search
   */
  applyFilter($event: any, stringVal: string) {
    this.dtStaff!.filterGlobal(
      ($event.target as HTMLInputElement).value,
      stringVal
    );

    this.dtCompany!.filterGlobal(
      ($event.target as HTMLInputElement).value,
      stringVal
    );
  }

  /**
   * get staff (astrio members) to fill table
   */
  getStaffUser() {
    this.loading = true;
    let role = this.staffForm.get('staffRole')?.value;
    this.staffService.getStaff(role).subscribe({
      next: (res) => {
        this.staffUsers = res;
        this.loading = false;
      },
      error: (err) => {
        this.alertService.displayError('Failed to get users');
      },
    });
  }

  /**
   * get users (company members) to fill table
   */
  getCompanyUser() {
    this.loading = true;
    const userType: User = {
      roleName: this.companyForm.get('companyRole')?.value,
      companyName: this.companyForm.get('companyName')?.value,
    };
    this.userService.getUser(userType).subscribe({
      next: (res) => {
        this.companyUsers = res;
        this.loading = false;
      },
      error: (err) => {
        this.alertService.displayError('Failed to get users');
      },
    });
  }

  /**
   * open dialog to view user
   */
  onViewUser(user: User) {
    this.dialog.open(ViewUserComponent, { data: user });
  }

  /**
   * open dialog to edit skill
   */
  onAddSkill(user: User) {
    this.dialog.open(UpdateSkillComponent, { data: user });
  }

  /**
   * open dialog to create user
   * index 0 refers to astrio staff tab
   * index 1 refers to company staff tab
   */
  onCreateUser() {
    let dialogRef = this.dialog.open(UpdateUserComponent, {
      data: this.selectedTabIndex,
    });
    dialogRef.afterClosed().subscribe(() => {
      if (this.selectedTabIndex == 0) {
        this.getStaffUser();
      } else if (this.selectedTabIndex == 1) {
        this.getCompanyUser();
      }
    });
  }

  /**
   * open dialog to update status
   * only for staff
   * @param { User } user user to be updated
   */
  onUpdateStatus(user: User) {
    let dialogRef = this.dialog.open(UpdateStatusComponent, {
      data: { username: user.username, currentStatus: user.statusName },
    });
    dialogRef.afterClosed().subscribe(() => {
      this.getStaffUser();
    });
  }
}
