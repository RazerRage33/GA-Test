import { SubmitReportComponent } from './../../../../dialogs/report/submit-report/submit-report.component';
import { Report } from './../../../../interface/Report';
import { JobService } from 'src/app/service/job.service';
import { ReportService } from './../../../../service/report.service';
import { AlertService } from 'src/app/service/alert.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Job } from 'src/app/interface/Job';
import { ROUTE } from 'src/app/APP_CONFIG';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-report-astrio',
  templateUrl: './report-astrio.component.html',
  styleUrls: ['./report-astrio.component.css'],
})
export class ReportAstrioComponent implements OnInit {
  private ticketId: string;
  private jobId: string;

  report: Report;
  jobActions: Job[];
  reportLoaded: Promise<boolean> = Promise.resolve(false);
  actionLoaded: Promise<boolean> = Promise.resolve(false);

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private alertService: AlertService,
    private reportService: ReportService,
    private jobService: JobService,
    private dialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.getQueryParams();
  }

  /**
   * get token from url
   */
  getQueryParams() {
    this.route.queryParams.subscribe((params: Job) => {
      if (params.ticketId && params.jobId) {
        this.ticketId = params.ticketId;
        this.jobId = params.jobId;
        this.getReport();
        this.getJobAction();
      } else {
        this.onBack();
        this.alertService.displayError('Please re-enter page');
      }
    });
  }

  /**
   * open page to view job action
   */
  onBack() {
    this.router.navigate(['../../' + ROUTE.JOB], {
      relativeTo: this.route,
    });
  }

  /**
   * get report to display in table
   */
  getReport() {
    this.reportService.getReport(this.ticketId).subscribe({
      next: (res) => {
        this.report = res;
        this.reportLoaded = Promise.resolve(true);
      },
      error: (err) => {
        this.alertService.displayError('Failed to get job actions');
      },
    });
  }

  /**
   * get jobs to display in table
   */
  getJobAction() {
    const jobQuery: Job = {
      jobId: this.jobId,
      status: '',
    };
    this.jobService.getJobAction(jobQuery).subscribe({
      next: (res) => {
        this.jobActions = res;
        this.actionLoaded = Promise.resolve(true);
      },
      error: (err) => {
        this.alertService.displayError('Failed to get job actions');
      },
    });
  }

  /**
   * print page
   */
  onDownload() {
    window.print();
  }

  /**
   * open dialog to upload pdf
   */
  onUpload() {
    this.dialog.open(SubmitReportComponent, { data: this.report });
  }
}
