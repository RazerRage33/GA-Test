import { Component, OnInit, ViewChild } from '@angular/core';
import { Table } from 'primeng/table';
import { MatDialog } from '@angular/material/dialog';
import { UpdateTicketComponent } from 'src/app/dialogs/ticket/update-ticket/update-ticket.component';
import { ViewTicketComponent } from 'src/app/dialogs/ticket/view-ticket/view-ticket.component';
import { Ticket } from 'src/app/interface/Ticket';
import { AlertService } from 'src/app/service/alert.service';
import { JobService } from 'src/app/service/job.service';
import { TicketService } from 'src/app/service/ticket.service';
import { FormControl, FormGroup } from '@angular/forms';
import { TABLE_STATUS } from 'src/app/APP_CONFIG';
import { UpdateJobComponent } from 'src/app/dialogs/job/update-job/update-job.component';

@Component({
  selector: 'app-ticket-astrio',
  templateUrl: './ticket-astrio.component.html',
  styleUrls: ['./ticket-astrio.component.css'],
})
export class TicketAstrioComponent implements OnInit {
  @ViewChild('dt') dt: Table | undefined;
  loading: boolean = true;
  tickets!: Ticket[];
  filterColumn: string[] = [
    'title',
    'projectName',
    'categoryName',
    'requestedOn',
    'statusName',
  ];

  ticketForm: FormGroup;
  tableStatus: string[] = TABLE_STATUS;

  constructor(
    private ticketService: TicketService,
    private dialog: MatDialog,
    private alertService: AlertService
  ) {}

  ngOnInit(): void {
    this.createFormGroup();
    this.getTicket();
  }

  /**
   * create FormGroup. one for staff, one for company
   */
  createFormGroup() {
    this.ticketForm = new FormGroup({
      status: new FormControl(this.tableStatus[0]),
    });

    this.ticketForm.valueChanges.subscribe(() => {
      this.getTicket();
    });
  }

  /**
   * get ticket to display in table
   */
  getTicket() {
    this.loading = true;
    let statusType: string = this.ticketForm.get('status')?.value;
    this.ticketService.getTicket(statusType).subscribe({
      next: (res) => {
        this.loading = false;
        this.tickets = res;
      },
      error: (err) => {
        this.alertService.displayError('Failed to get tickets');
      },
    });
  }

  /**
   * filter search
   */
  applyFilter($event: any, stringVal: string) {
    this.dt!.filterGlobal(($event.target as HTMLInputElement).value, stringVal);
  }

  /**
   * open dialog to view ticket
   * at the same time, update ticket status to 'processed'
   */
  onViewTicket(ticket: Ticket) {
    this.ticketService.processTicket(ticket).subscribe({
      next: () => {
        let dialogRef = this.dialog.open(ViewTicketComponent, { data: ticket });
        dialogRef.afterClosed().subscribe(() => {
          this.getTicket();
        });
      },
      error: (err) => {
        this.alertService.displayError('Please try again');
      },
    });
  }

  /**
   * open dialog to acknowledge ticket and create job
   * @param {Ticket} ticket ticket to be acknowledged
   */
  onCreateJob(ticket: Ticket) {
    let dialogRef = this.dialog.open(UpdateJobComponent, { data: ticket });
    dialogRef.afterClosed().subscribe(() => {
      this.getTicket();
    });
  }
}
