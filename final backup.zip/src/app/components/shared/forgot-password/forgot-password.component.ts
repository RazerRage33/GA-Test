import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ROUTE } from 'src/app/APP_CONFIG';
import { CustomErrorStateMatcher } from 'src/app/CustomErrorStateMatcher';
import { AlertService } from 'src/app/service/alert.service';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css'],
})
export class ForgotPasswordComponent implements OnInit {
  emailForm!: FormGroup;
  hidePassword: boolean = true;
  submitted: boolean = false;
  matcher = new CustomErrorStateMatcher();
  email: string;

  constructor(
    private userService: UserService,
    private alertService: AlertService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.createFormGroup();
  }

  /**
   * go back login page
   */
  onBack() {
    this.router.navigate([ROUTE.LOGIN]);
  }

  /**
   * create FormGroup
   */
  createFormGroup() {
    this.emailForm = new FormGroup({
      email: new FormControl(null, [Validators.required, Validators.email]),
    });
  }

  /**
   * validate form
   */
  onSubmit() {
    if (this.emailForm.valid) {
      this.forgotPassword(this.emailForm.get('email')?.value);
    }
  }

  /**
   * send email to api for request to reset password
   * @param {string} email email to be sent
   */
  forgotPassword(email: string) {
    this.userService.forgotPassword(email).subscribe({
      next: () => {
        this.alertService.displaySuccess('Email sent!');
        this.email = email;
        this.submitted = true;
      },
      error: (err) => {
        this.alertService.displayError('Invalid email');
      },
    });
  }
}
