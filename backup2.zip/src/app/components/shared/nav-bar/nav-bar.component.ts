import { FileService } from './../../../service/file.service';
import { UserService } from 'src/app/service/user.service';
import { TicketService } from 'src/app/service/ticket.service';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { Observable, Subject, takeUntil } from 'rxjs';
import { ROUTE } from 'src/app/APP_CONFIG';
import { Menu } from 'src/app/interface/Menu';
import { AlertService } from 'src/app/service/alert.service';
import { AuthService } from 'src/app/service/auth.service';
import { User } from 'src/app/interface/User';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css'],
})
export class NavBarComponent implements OnInit, OnDestroy {
  showNav$: Observable<boolean>;
  dataLoaded: Promise<boolean> = Promise.resolve(false);
  routes = ROUTE;
  menus: Menu[];
  user: User;
  hasImage: boolean;
  image = new Array();

  // ticket count to display on the sidebar
  ticketCount: string;

  // to unsubscribe to subscription
  private ngUnsubscribe = new Subject<void>();

  constructor(
    private authService: AuthService,
    private alertService: AlertService,
    private ticketService: TicketService,
    private userService: UserService,
    private fileService: FileService
  ) {}

  ngOnInit(): void {
    this.bindTopNav();
    this.showNav$ = this.authService.isLoggedIn;
    this.authService.isLoggedIn
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe((res: boolean) => {
        if (res) {
          this.getMenu();
          this.getProfile();
          this.getTicketCount();
        }
      });
  }

  ngOnDestroy(): void {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  /**
   * open side nav
   */
  openMenu() {
    const sideMenu = document.querySelector('aside');
    sideMenu!.style.display = 'block';
  }

  /**
   * close side nav
   */
  closeMenu() {
    const sideMenu = document.querySelector('aside');
    sideMenu!.style.display = 'none';
  }

  /**
   * top nav animation
   */
  bindTopNav() {
    let prevScrollpos = window.pageYOffset;
    window.onscroll = function () {
      let currentScrollPos = window.pageYOffset;
      if (prevScrollpos > currentScrollPos) {
        document.getElementById('navbar')!.style.top = '0';
        document.getElementById('navbar')!.style.boxShadow =
          '0 1rem 1rem rgba(132, 139, 200, 0.18)';
      } else {
        document.getElementById('navbar')!.style.top = '-4.6rem';
        document.getElementById('navbar')!.style.boxShadow = 'none';
      }
      prevScrollpos = currentScrollPos;
    };
  }

  /**
   * get profile
   */
  getProfile() {
    this.userService.getProfile().subscribe({
      next: (res: User) => {
        this.user = res;
        this.getImage();
      },
      error: (err) => {
        console.log('Failed to get user');
      },
    });
  }

  /**
   * get dynamic menu
   */
  getMenu() {
    this.authService.getMenu().subscribe({
      next: (res) => {
        this.menus = res;
      },
      error: (err) => {
        console.log('Failed to get menu');
      },
    });
  }

  /**
   * get image using image path from database
   */
  getImage() {
    if (this.user.logoPath) {
      this.fileService
        .getFileAsBlob(this.user.companyName!, this.user.logoPath)
        .subscribe({
          next: (image: Blob) => {
            this.hasImage = true;
            this.blobToImageToDisplay(image);
          },
          error: (err) => {
            this.alertService.displayError('Failed to load image');
          },
        });
    } else {
      this.hasImage = false;
      this.dataLoaded = Promise.resolve(true);
    }
  }

  /**
   * convert blob to image to display
   * @param  {Blob} image image file
   */
  blobToImageToDisplay(image: Blob) {
    let reader = new FileReader();
    reader.addEventListener(
      'load',
      () => {
        this.image.push(reader.result);
      },
      false
    );
    if (image) {
      reader.readAsDataURL(image);
    }
    this.dataLoaded = Promise.resolve(true);
  }

  /**
   * get count of number of ticket that is either of status:
   * submitted, processed, confirmed
   * auto selected based on roles
   */
  getTicketCount() {
    this.ticketService.getTicketCount().subscribe({
      next: (res) => {
        this.ticketCount = res;
      },
      error: (err) => {
        console.log('Failed to get ticket count');
      },
    });
  }

  /**
   * logout
   */
  logout() {
    this.authService.logout().subscribe({
      next: () => {
        this.alertService.displayInfo('Logged out');
      },
      error: (err) => {
        this.alertService.displayError('Failed to logout');
      },
    });
  }
}
