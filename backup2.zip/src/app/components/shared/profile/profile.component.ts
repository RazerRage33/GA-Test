import { UpdateStatusComponent } from './../../../dialogs/user/update-status/update-status.component';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ChangePasswordComponent } from 'src/app/dialogs/user/change-password/change-password.component';
import { UpdateProfileComponent } from 'src/app/dialogs/user/update-profile/update-profile.component';
import { User } from 'src/app/interface/User';
import { AlertService } from 'src/app/service/alert.service';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css'],
})
export class ProfileComponent implements OnInit {
  user: User;
  dataLoaded: Promise<boolean> = Promise.resolve(false);
  isStaff: boolean;

  constructor(
    private userService: UserService,
    private dialog: MatDialog,
    private alertService: AlertService
  ) {}

  ngOnInit(): void {
    this.getProfile();
  }

  /**
   * get profile information
   */
  getProfile() {
    this.userService.getProfile().subscribe({
      next: (res) => {
        this.user = res;
        this.checkStaff();
      },
      error: (err) => {
        this.alertService.displayError('Failed to get profile');
      },
    });
  }

  /**
   * check if user is a staff
   */
  checkStaff() {
    if (this.user.companyName == 'ASTrio Pte Ltd') {
      this.isStaff = true;
    }
    this.dataLoaded = Promise.resolve(true);
  }

  /**
   * open dialog to edit profile information
   */
  onEditUser() {
    let dialogRef = this.dialog.open(UpdateProfileComponent, {
      data: this.user,
    });
    dialogRef.afterClosed().subscribe(() => {
      this.getProfile();
    });
  }

  /**
   * open dialog to update status
   */
  onUpdateStatus() {
    let dialogRef = this.dialog.open(UpdateStatusComponent, {
      data: { username: this.user.username, currentStatus: this.user.status },
    });
    dialogRef.afterClosed().subscribe(() => {
      this.getProfile();
    });
  }

  /**
   * open dialog to change password
   */
  onChangePassword() {
    this.dialog.open(ChangePasswordComponent);
  }
}
