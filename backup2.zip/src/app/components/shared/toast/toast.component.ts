import { Toast } from './../../../interface/Toast';
import { Component, OnInit } from '@angular/core';
import { MessageService } from 'primeng/api';
import { Subject, takeUntil } from 'rxjs';
import { AlertService } from 'src/app/service/alert.service';

@Component({
  selector: 'app-toast',
  templateUrl: './toast.component.html',
  styleUrls: ['./toast.component.css'],
  providers: [MessageService],
})
export class ToastComponent implements OnInit {
  private ngUnsubscribe = new Subject<void>();

  constructor(
    private messageService: MessageService,
    private alertService: AlertService
  ) {}

  ngOnInit(): void {
    this.getToast();
  }

  /**
   * unsubscribe to all subscription
   */
  ngOnDestroy(): void {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  /**
   * subscribe to toast obserable from service
   * each time the behaviorable subject is updated,
   * this will be called
   */
  getToast() {
    this.alertService.toast
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe((res: Toast) => {
        if (res) {
          this.displayToast(res);
        }
      });
  }

  /**
   * display toast with message
   * @param { Toast } toast toast object with message
   */
  displayToast(toast: Toast) {
    this.messageService.add({
      severity: toast.severity,
      summary: toast.summary,
      detail: toast.detail,
    });
  }
}
