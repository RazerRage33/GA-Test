import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { switchMap } from 'rxjs';
import { ROUTE } from 'src/app/APP_CONFIG';
import { User } from 'src/app/interface/User';
import { AlertService } from 'src/app/service/alert.service';
import { AuthService } from 'src/app/service/auth.service';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginPageComponent implements OnInit {
  loginForm!: FormGroup;
  hidePassword: boolean = true;

  constructor(
    private authService: AuthService,
    private router: Router,
    private alertService: AlertService,
    private userService: UserService
  ) {}

  ngOnInit(): void {
    localStorage.clear();
    this.authService.logout().subscribe();
    this.createFormGroup();
  }

  /**
   * create FormGroup
   */
  createFormGroup() {
    this.loginForm = new FormGroup({
      username: new FormControl('', Validators.required),
      password: new FormControl('', Validators.required),
    });
  }

  /**
   * validate form
   */
  onSubmit() {
    if (this.loginForm.valid) {
      const user: User = {
        username: this.loginForm.get('username')?.value,
        password: this.loginForm.get('password')?.value,
      };
      this.login(user);
    }
  }

  /**
   * route to forgot password page
   */
  onForgotPassword() {
    this.router.navigate([ROUTE.FORGOT_PASSWORD]);
  }

  /**
   * validate user and login to website, save user object
   * get home page link
   * @param  {User} user user details to submit
   */
  login(user: User) {
    let authFlow = this.authService
      .validateUser(user)
      .pipe(switchMap(() => this.userService.getProfile()));
    authFlow.subscribe({
      next: (user: User) => {
        if (user.homePage) {
          this.userService.saveUserToLocalStorage(user);
          this.authService.setLoggedIn = true;
          this.authService.setUserHomePage = user.homePage;
          this.router.navigate([this.authService.userHomePage]);
        }
      },
      error: (err) => {
        this.alertService.displayError('Invalid details');
      },
    });
  }
}
