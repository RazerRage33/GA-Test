import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-astrio-user',
  templateUrl: './dashboard-astrio-user.component.html',
  styleUrls: ['./dashboard-astrio-user.component.css']
})
export class DashboardAstrioUserComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
