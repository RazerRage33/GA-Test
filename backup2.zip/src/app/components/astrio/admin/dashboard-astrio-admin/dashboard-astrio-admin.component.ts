import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { UpdateStatusComponent } from 'src/app/dialogs/user/update-status/update-status.component';
import { User } from 'src/app/interface/User';
import { AlertService } from 'src/app/service/alert.service';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-dashboard-astrio-admin',
  templateUrl: './dashboard-astrio-admin.component.html',
  styleUrls: ['./dashboard-astrio-admin.component.css'],
})
export class DashboardAstrioAdminComponent implements OnInit {
  user: User;

  constructor(
    private userService: UserService,
    private alertService: AlertService,
    private dialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.getProfile();
  }

  /**
   * get profile information
   */
  getProfile() {
    this.userService.getProfile().subscribe({
      next: (res) => {
        this.user = res;
      },
      error: (err) => {
        this.alertService.displayError('Failed to get profile');
      },
    });
  }

  /**
   * open dialog to update status
   */
  onUpdateStatus() {
    let dialogRef = this.dialog.open(UpdateStatusComponent, {
      data: { username: this.user.username, currentStatus: this.user.status },
    });
    dialogRef.afterClosed().subscribe(() => {
      this.getProfile();
    });
  }
}
