import { FormControl, FormGroup } from '@angular/forms';
import { CloseJobComponent } from './../../../../dialogs/job/close-job/close-job.component';
import { JobService } from '../../../../service/job.service';
import { Job } from '../../../../interface/Job';
import { Component, OnInit, ViewChild } from '@angular/core';
import { Table } from 'primeng/table';
import { AlertService } from 'src/app/service/alert.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ROUTE, TABLE_STATUS } from 'src/app/APP_CONFIG';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-job-astrio',
  templateUrl: './job-astrio.component.html',
  styleUrls: ['./job-astrio.component.css'],
})
export class JobAstrioComponent implements OnInit {
  @ViewChild('dt') dt: Table | undefined;
  loading: boolean = true;
  jobs!: Job[];
  filterColumn: string[] = ['ticketTitle', 'startDate', 'totalManhours'];
  jobForm: FormGroup;
  tableStatus: string[] = TABLE_STATUS;

  constructor(
    private jobService: JobService,
    private alertService: AlertService,
    private router: Router,
    private route: ActivatedRoute,
    private dialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.createFormGroup();
    this.getJob();
  }

  /**
   * get jobs to display in table
   */
  getJob() {
    let statusType: string = this.jobForm.get('status')?.value;
    this.loading = true;
    this.jobService.getJob(statusType).subscribe({
      next: (res) => {
        this.loading = false;
        this.jobs = res;
      },
      error: (err) => {
        this.alertService.displayError('Failed to get jobs');
      },
    });
  }

  /**
   * filter search
   */
  applyFilter($event: any, stringVal: string) {
    this.dt!.filterGlobal(($event.target as HTMLInputElement).value, stringVal);
  }

  /**
   * create FormGroup. one for staff, one for company
   */
  createFormGroup() {
    this.jobForm = new FormGroup({
      status: new FormControl(this.tableStatus[0]),
    });

    this.jobForm.valueChanges.subscribe(() => {
      this.getJob();
    });
  }

  /**
   * open page to view job action
   * @param { Job } job job to view
   */
  onViewJobAction(job: Job) {
    this.router.navigate(['../' + ROUTE.JOB_ACTION], {
      relativeTo: this.route,
      queryParams: { id: job.id, ticketTitle: job.ticketTitle },
    });
  }

  /**
   * open page to view job report
   * @param { Job } job job report to view
   */
  onViewReport(job: Job) {
    this.router.navigate(['../' + ROUTE.REPORT], {
      relativeTo: this.route,
      queryParams: { ticketId: job.ticketId, jobId: job.id },
    });
  }

  /**
   * open page to close job
   * @param { Job } job job to close
   */
  onCloseJob(job: Job) {
    let dialogRef = this.dialog.open(CloseJobComponent, {
      data: job,
    });
    dialogRef.afterClosed().subscribe(() => {
      this.getJob();
    });
  }
}
