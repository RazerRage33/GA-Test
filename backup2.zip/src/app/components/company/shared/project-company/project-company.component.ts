import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Table } from 'primeng/table';
import { ViewProjectComponent } from 'src/app/dialogs/project/view-project/view-project.component';
import { Project } from 'src/app/interface/Project';
import { AlertService } from 'src/app/service/alert.service';
import { ProjectService } from 'src/app/service/project.service';

@Component({
  selector: 'app-project-company',
  templateUrl: './project-company.component.html',
  styleUrls: ['./project-company.component.css'],
})
export class ProjectCompanyComponent implements OnInit {
  @ViewChild('dt') dt: Table | undefined;
  loading: boolean = true;
  projects!: Project[];
  filterColumn: string[] = ['name', 'createdOn', 'updatedOn'];

  constructor(
    private projectService: ProjectService,
    private dialog: MatDialog,
    private alertService: AlertService
  ) {}

  ngOnInit(): void {
    this.getProject();
  }

  /**
   * get project to display in table
   */
  getProject() {
    this.loading = true;
    this.projectService.getProjectByUser().subscribe({
      next: (res) => {
        this.loading = false;
        this.projects = res;
      },
      error: (err) => {
        this.alertService.displayError('Failed to get projects');
      },
    });
  }

  /**
   * filter search
   */
  applyFilter($event: any, stringVal: string) {
    this.dt!.filterGlobal(($event.target as HTMLInputElement).value, stringVal);
  }

  /**
   * open dialog to view project
   */
  onViewProject(project: Project) {
    this.dialog.open(ViewProjectComponent, { data: project });
  }
}
