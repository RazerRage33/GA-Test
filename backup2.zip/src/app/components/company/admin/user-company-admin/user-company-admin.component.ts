import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Table } from 'primeng/table';
import { UpdateUserComponent } from 'src/app/dialogs/user/update-user/update-user.component';
import { ViewUserComponent } from 'src/app/dialogs/user/view-user/view-user.component';
import { Company } from 'src/app/interface/Company';
import { User } from 'src/app/interface/User';
import { AlertService } from 'src/app/service/alert.service';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-user-company-admin',
  templateUrl: './user-company-admin.component.html',
  styleUrls: ['./user-company-admin.component.css'],
})
export class UserCompanyAdminComponent implements OnInit {
  roles: string[] = ['User', 'Admin'];
  loading: boolean = true;

  // company section
  companies: Company[];
  companyUsers: User[];
  companyForm: FormGroup;
  @ViewChild('dtCompany') dtCompany: Table | undefined;
  filterCompanyColumn: string[] = ['username', 'email', 'phoneNumber'];

  constructor(
    private alertService: AlertService,
    private userService: UserService,
    private dialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.createFormGroup();
    this.getCompanyUser();
  }

  /**
   * create FormGroup.
   */
  createFormGroup() {
    this.companyForm = new FormGroup({
      companyRole: new FormControl(this.roles[0]),
    });

    this.companyForm.valueChanges.subscribe((res) => {
      this.getCompanyUser();
    });
  }

  /**
   * filter search
   */
  applyFilter($event: any, stringVal: string) {
    this.dtCompany!.filterGlobal(
      ($event.target as HTMLInputElement).value,
      stringVal
    );
  }

  /**
   * get users (company members) to fill table
   */
  getCompanyUser() {
    this.loading = true;
    const userType: User = {
      roleName: this.companyForm.get('companyRole')?.value,
      companyName: '',
    };
    this.userService.getUser(userType).subscribe({
      next: (res) => {
        this.companyUsers = res;
        this.loading = false;
      },
      error: (err) => {
        this.alertService.displayError('Failed to get users');
      },
    });
  }

  /**
   * open dialog to view user
   */
  onViewUser(user: User) {
    this.dialog.open(ViewUserComponent, { data: user });
  }

  /**
   * open dialog to create user
   * data = 3 to set dialog into create user of own company
   */
  onCreateUser() {
    let dialogRef = this.dialog.open(UpdateUserComponent, { data: 3 });
    dialogRef.afterClosed().subscribe(() => {
      this.getCompanyUser();
    });
  }
}
