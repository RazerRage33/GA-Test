import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-company-user',
  templateUrl: './dashboard-company-user.component.html',
  styleUrls: ['./dashboard-company-user.component.css']
})
export class DashboardCompanyUserComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
