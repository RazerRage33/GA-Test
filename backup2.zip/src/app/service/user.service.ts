import { Password } from './../interface/Password';
import { User } from 'src/app/interface/User';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { API_URL, HTTP_OPTION } from '../APP_CONFIG';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  constructor(private http: HttpClient) {}

  /**
   * get profile from API
   * @return {any}  profile observable
   */
  getProfile(): Observable<any> {
    // return this.http.post(API_URL + 'Auth/Login', httpOption);
    return this.http.get(API_URL + 'User/Profile', HTTP_OPTION);
  }

  /**
   * save user object in local storage
   * @param  {User} user  user to be saved in local storage
   */
  saveUserToLocalStorage(user: User) {
    console.log(user);
    localStorage.removeItem('user');
    localStorage.setItem('user', JSON.stringify(user));
  }

  /**
   * get user object from local storage
   * @return user object
   */
  getUserFromLocalStorage() {
    let user: User;
    user = JSON.parse(localStorage.getItem('user')!);
    return user;
  }

  /**
   * change password request to API
   * @param  {Password} password  password to be submitted
   * @return {any}  password change status
   */
  changePassword(password: Password): Observable<any> {
    return this.http.post(
      API_URL + 'User/UpdatePassword',
      password,
      HTTP_OPTION
    );
  }

  /**
   * update user information request to API
   * @param  {User} user user info to be submitted
   * @return {any}  user info change status
   */
  updateUserInfo(user: User): Observable<any> {
    return this.http.post(
      API_URL + 'User/UpdateInformation',
      user,
      HTTP_OPTION
    );
  }

  /**
   * forgot password request to API
   * @param  {string} email email to be submitted
   * @return {any}  forgot password status
   */
  forgotPassword(email: string): Observable<any> {
    return this.http.get(API_URL + 'User/ForgotPassword/' + email, HTTP_OPTION);
  }

  /**
   * reset password request to API
   * @param  {Password} password password to be submitted
   * @return {any}  reset password status
   */
  resetPassword(password: Password): Observable<any> {
    return this.http.post(
      API_URL + 'User/ResetPassword',
      password,
      HTTP_OPTION
    );
  }

  /**
   * get user request to API
   * @param  {User} userType user type to be queried
   * @return {any}  users
   */
  getUser(userType: User): Observable<User[]> {
    return this.http.post<User[]>(
      API_URL + 'User/GetAllCompanyUserInformation/',
      userType,
      HTTP_OPTION
    );
  }

  /**
   * create user request to API
   * @param  {User} user user to be created
   * @return {any}  users
   */
  createUser(user: User): Observable<User[]> {
    return this.http.post<User[]>(API_URL + 'User/Create', user, HTTP_OPTION);
  }
}
