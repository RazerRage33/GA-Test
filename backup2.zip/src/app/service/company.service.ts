import { Contract } from './../interface/Contract';
import { API_URL, HTTP_OPTION } from './../APP_CONFIG';
import { Injectable } from '@angular/core';
import { Company } from '../interface/Company';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Project } from '../interface/Project';

@Injectable({
  providedIn: 'root',
})
export class CompanyService {
  constructor(private http: HttpClient) {}

  /**
   * get user's company
   * @return {string}  all company
   */
  getUserCompany() {
    return this.http.get(API_URL + 'Company', {
      withCredentials: true,
      responseType: 'text',
    });
  }

  /**
   * get all company from database
   * @return {Company[]}  all company
   */
  getCompany(): Observable<Company[]> {
    return this.http.get<Company[]>(API_URL + 'Company/All', HTTP_OPTION);
  }

  /**
   * get all company with contract from database
   * @return {Company[]}  all company
   */
  getCompanyWithContract(): Observable<Company[] & Contract[]> {
    return this.http.get<Company[] & Contract[]>(
      API_URL + 'Company/AllWithContractInformation',
      HTTP_OPTION
    );
  }

  /**
   * create company request to API
   * @param  {Company} company user info to be submitted
   * @return {any}  create company status
   */
  createCompany(formData: FormData): Observable<any> {
    return this.http.post<any>(
      API_URL + 'Company/Create',
      formData,
      HTTP_OPTION
    );
  }

  /**
   * update company request to API
   * @param  {Company} company user info to be submitted
   * @return {any}  update company status
   */
  updateCompany(formData: FormData): Observable<any> {
    return this.http.post<any>(
      API_URL + 'Company/Update',
      formData,
      HTTP_OPTION
    );
  }

  /**
   * send project and company link to api to update
   * @param {Project[]} project project and company link to be updated
   */
  linkCompanyWithProject(project: Project[]) {
    return this.http.post<Project[]>(
      API_URL + 'Company/LinkCompanyToProject',
      project,
      HTTP_OPTION
    );
  }
}
