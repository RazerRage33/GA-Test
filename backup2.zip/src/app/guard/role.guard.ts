import { AlertService } from 'src/app/service/alert.service';
import { ROUTE } from 'src/app/APP_CONFIG';
import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  CanActivate,
  Router,
  RouterStateSnapshot,
  UrlTree,
} from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from '../service/auth.service';

@Injectable({
  providedIn: 'root',
})
export class RoleGuard implements CanActivate {
  constructor(
    private authService: AuthService,
    private router: Router,
    private alertService: AlertService
  ) {}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ):
    | Observable<boolean | UrlTree>
    | Promise<boolean | UrlTree>
    | boolean
    | UrlTree {
    // get path without parameters
    let routePath: string = state.url.substring(1).split('?')[0];
    this.authService.haveAccess(routePath).subscribe({
      next: (res) => {
        if (res == 'true') {
          return true;
        } else {
          this.alertService.displayError('Unauthorized!');
          console.log(this.authService.userHomePage);
          this.router.navigate([this.authService.userHomePage]);
          return false;
        }
      },
      error: (err) => {
        this.alertService.displayError('An error has occured');
        this.authService.logout().subscribe({
          next: () => {
            this.alertService.displayInfo('Logged out');
          },
          error: (err) => {
            this.alertService.displayError('Failed to logout');
          },
        });
        return false;
      },
    });
    return true;
  }
}
