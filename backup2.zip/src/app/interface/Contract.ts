export interface Contract {
  // contract id
  id?: string;
  projectName?: string;
  projectId?: string;
  typeName?: string;
  details?: string;
  companyName?: string;
  manhoursTotal?: string;
  manhoursUsed?: string;
  manhoursRemaining?: string;
  startDate?: string;
  endDate?: string;
  requestedBy?: string;
  requestedOn?: string;
  updatedBy?: string;
  updatedOn?: string; 

  // contract type
  name?: string;
  description?: string;
}
