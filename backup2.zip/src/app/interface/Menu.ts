export interface Menu {
  menuId?: string;
  name?: string;
  link?: string;
  icon?: string;
  toLoad?: string;
}
