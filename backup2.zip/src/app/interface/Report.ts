export interface Report {
  id?: string;
  ticketId?: string;
  jobId?: string;
  title?: string;
  companyName?: string;
  projectName?: string;
  description?: string;
  diagnosticReport?: string;
  categoryName?: string;
  fileNameWithExtension?: string;
  imageNameWithExtension1?: string;
  imageNameWithExtension2?: string;
  manhoursTotal?: string;
  manhoursRemaining?: string;
  manhoursUsed?: string;
  startDate?: string;
  endDate?: string;
  requestedBy?: string;
  requestedOn?: string;
  reportFile?: File;
}
