export interface Company {
  name?: string;
  location?: string;
  description?: string;
  logoPath?: string;
  contactName1?: string;
  contactName2?: string;
  contactEmail1?: string;
  contactEmail2?: string;
  contactNo1?: string;
  contactNo2?: string;
  adminCount?: string;
  totalCount?: string;
  userCount?: string;
  createdByUsername?: string;
  createdOn?: string;

  // update company
  oldName?: string;
  logo?: File; 
}
