export interface Job {
  id?: string;
  ticketId?: string;
  ticketTitle?: string;
  startDate?: string;
  endDate?: string;
  totalManhours?: string;
  createdBy?: string;
  createdOn?: string;
  updatedBy?: string;
  updatedOn?: string;
  diagnosticReport?: string;

  //job action
  title?: string;
  jobId?: string;
  status?: string;
  staffName?: string;
  description?: string;
  manHoursUsed?: string;
  autoAssignSetting?: boolean;
}
