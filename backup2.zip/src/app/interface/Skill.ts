export interface Skill {
  name?: string;
  description?: string;

  staffName?: string;
  skillName?: string;
}
