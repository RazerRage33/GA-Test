import { FileService } from './../../../service/file.service';
import { Report } from './../../../interface/Report';
import { ReportService } from './../../../service/report.service';
import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AlertService } from 'src/app/service/alert.service';

@Component({
  selector: 'app-submit-report',
  templateUrl: './submit-report.component.html',
  styleUrls: ['./submit-report.component.css'],
})
export class SubmitReportComponent implements OnInit {
  uploadedFile: File;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: Report,
    private alertService: AlertService,
    private reportService: ReportService,
    private fileService: FileService,
    private dialogRef: MatDialogRef<SubmitReportComponent>
  ) {}

  ngOnInit(): void {}

  /**
   * validate file for further actions
   * @param  {any} event button event
   */
  onFileSelected(event: any) {
    if (<File>event.target!.files[0]) {
      let file: File = <File>event.target!.files[0];
      if (this.fileService.validatePdfFile(file)) {
        this.uploadedFile = file;
      }
    }
  }

  /**
   * validate form
   */
  onSubmit() {
    console.log(this.uploadedFile);
    if (this.uploadedFile) {
      const report: Report = {
        id: this.data.jobId,
        companyName: this.data.companyName,
        reportFile: this.uploadedFile ? this.uploadedFile : null!,
      };
      this.createFormData(report);
    } else {
      this.alertService.displayWarning('Select file');
    }
  }

  /**
   * create FormData from report object
   * @param  {Report} report report to be submitted
   */
  createFormData(report: Report) {
    const formData = new FormData();
    for (let key in report) {
      if (report[key as keyof Report] == null) {
        formData.append(key, '');
        continue;
      }
      formData.append(key, report[key as keyof Report]!);
    }
    this.createTicket(formData);
  }

  /**
   * create ticket from formdata
   * @param  {FormData} formData ticket to be created
   */
  createTicket(formData: FormData) {
    this.reportService.uploadReport(formData).subscribe({
      next: () => {
        this.dialogRef.close();
        this.alertService.displaySuccess('Uploaded report');
      },
      error: (err) => {
        this.alertService.displayError('Please try again');
      },
    });
  }
}
