import { UserService } from 'src/app/service/user.service';
import { User } from 'src/app/interface/User';
import { Company } from './../../../interface/Company';
import { AlertService } from './../../../service/alert.service';
import { CompanyService } from './../../../service/company.service';
import { Component, Inject, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { CustomErrorStateMatcher } from 'src/app/CustomErrorStateMatcher';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-update-user',
  templateUrl: './update-user.component.html',
  styleUrls: ['./update-user.component.css'],
})
export class UpdateUserComponent implements OnInit {
  matcher = new CustomErrorStateMatcher();
  userForm: FormGroup;
  companies: Company[];

  constructor(
    private companyService: CompanyService,
    private alertService: AlertService,
    private userService: UserService,
    private dialogRef: MatDialogRef<UpdateUserComponent>,
    @Inject(MAT_DIALOG_DATA) public data: number
  ) {}

  ngOnInit(): void {
    if (this.data != 3) {
      this.getCompany();
    }
    this.createFormGroup();
  }

  /**
   * get company to display in table
   */
  getCompany() {
    this.companyService.getCompany().subscribe({
      next: (res: Company[]) => {
        this.companies = res;
      },
      error: (err) => {
        this.alertService.displayWarning('Failed to get company');
      },
    });
  }

  /**
   * create FormGroup with no values
   */
  createFormGroup() {
    this.userForm = new FormGroup({
      username: new FormControl(null, Validators.required),
      password: new FormControl(null, Validators.required),
      email: new FormControl(null, [Validators.required, Validators.email]),
      phoneNumber: new FormControl('', [
        Validators.pattern('^[0-9]*$'),
        Validators.minLength(8),
        Validators.maxLength(8),
        Validators.required,
      ]),
      roleName: new FormControl('user', Validators.required),
      companyName: new FormControl(null, Validators.required),
    });

    // if creating staff, need fill this in to ignore the field when validating
    if (this.data == 0 || this.data == 3) {
      this.userForm.patchValue({
        companyName: 'company',
      });
    }
  }

  /**
   * validate form
   */
  onSubmit() {
    if (this.userForm.valid) {
      if (this.data == 0 || this.data == 3) {
        this.createUserObject();
      } else if (this.data == 1) {
        this.createCompanyUserObject();
      }
    }
  }

  /**
   * create staff/user of same company object
   */
  createUserObject() {
    this.companyService.getUserCompany().subscribe({
      next: (company: string) => {
        const user: User = {
          username: this.userForm.get('username')?.value,
          password: this.userForm.get('password')?.value,
          email: this.userForm.get('email')?.value,
          phoneNumber: this.userForm.get('phoneNumber')?.value,
          roleName: this.userForm.get('roleName')?.value,
          companyName: company,
        };
        this.createUser(user);
      },
      error: (err) => {
        this.alertService.displayError('Please try again');
      },
    });
  }

  /**
   * create staff object
   */
  createCompanyUserObject() {
    const user: User = {
      username: this.userForm.get('username')?.value,
      password: this.userForm.get('password')?.value,
      email: this.userForm.get('email')?.value,
      phoneNumber: this.userForm.get('phoneNumber')?.value,
      roleName: this.userForm.get('roleName')?.value,
      companyName: this.userForm.get('companyName')?.value,
    };
    this.createUser(user);
  }

  /**
   * submit create user to API
   * @param  {User} user user to be created
   */
  createUser(user: User) {
    this.userService.createUser(user).subscribe({
      next: () => {
        this.dialogRef.close();
        this.alertService.displaySuccess('Created user: ' + user.username);
      },
      error: (err: HttpErrorResponse) => {
        this.alertService.displayError(err.error);
      },
    });
  }
}
