import { Contract } from 'src/app/interface/Contract';
import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-view-contract',
  templateUrl: './view-contract.component.html',
  styleUrls: ['./view-contract.component.css'],
})
export class ViewContractComponent implements OnInit {
  constructor(@Inject(MAT_DIALOG_DATA) public data: Contract) {}

  ngOnInit(): void {}
}
