import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Job } from 'src/app/interface/Job';

@Component({
  selector: 'app-view-action',
  templateUrl: './view-action.component.html',
  styleUrls: ['./view-action.component.css']
})
export class ViewActionComponent implements OnInit {

  constructor(@Inject(MAT_DIALOG_DATA) public data: Job) { }

  ngOnInit(): void {
  }

}
