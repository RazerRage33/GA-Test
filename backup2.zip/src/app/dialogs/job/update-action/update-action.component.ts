import { JobService } from './../../../service/job.service';
import { Job } from '../../../interface/Job';
import { AlertService } from '../../../service/alert.service';
import { StaffService } from '../../../service/staff.service';
import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Ticket } from 'src/app/interface/Ticket';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-update-action',
  templateUrl: './update-action.component.html',
  styleUrls: ['./update-action.component.css'],
})
export class UpdateActionComponent implements OnInit {
  staffs: Job[];
  actionForm: FormGroup;

  constructor(
    private staffService: StaffService,
    private alertService: AlertService,
    private jobService: JobService,
    private dialogRef: MatDialogRef<UpdateActionComponent>,
    @Inject(MAT_DIALOG_DATA) public data: string
  ) {}

  ngOnInit(): void {
    this.createFormGroup();
    this.getStaff();
  }

  /**
   * get staffs available for action
   */
  getStaff() {
    this.staffService.getStaffName().subscribe({
      next: (res) => {
        this.staffs = res;
      },
      error: (err) => {
        this.alertService.displayError('Failed to get staff.');
      },
    });
  }

  /**
   * create FormGroup with no values
   */
  createFormGroup() {
    this.actionForm = new FormGroup({
      staff: new FormControl(null, Validators.required),
      title: new FormControl(null, Validators.required),
      description: new FormControl(null, Validators.required),
    });
  }

  /**
   * validate form
   */
  onSubmit() {
    let staff = this.actionForm.get('staff')?.value;
    let autoAssign: boolean = false;
    if (staff == 'auto') {
      autoAssign = true;
      staff = '';
    }
    const jobAction: Job = {
      jobId: this.data,
      staffName: staff,
      title: this.actionForm.get('title')?.value,
      description: this.actionForm.get('description')?.value,
      autoAssignSetting: autoAssign,
    };
    this.createAction(jobAction);
  }

  /**
   * submit action to API
   * @param  {Job} jobAction action to be submitted
   */
  createAction(jobAction: Job) {
    this.jobService.createJobAction(jobAction).subscribe({
      next: () => {
        this.alertService.displaySuccess('Action successfully created');
        this.dialogRef.close(); // if valid and complete den close
      },
      error: (err) => {
        this.alertService.displayError(err.error);
      },
    });
  }
}
