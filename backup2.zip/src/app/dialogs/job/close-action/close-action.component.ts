import { HttpErrorResponse } from '@angular/common/http';
import { Job } from 'src/app/interface/Job';
import { JobService } from 'src/app/service/job.service';
import { Component, Inject, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { AlertService } from 'src/app/service/alert.service';

@Component({
  selector: 'app-close-action',
  templateUrl: './close-action.component.html',
  styleUrls: ['./close-action.component.css'],
})
export class CloseActionComponent implements OnInit {
  actionForm!: FormGroup;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: string,
    private jobService: JobService,
    private dialogRef: MatDialogRef<CloseActionComponent>,
    private alertService: AlertService
  ) {}

  ngOnInit(): void {
    this.createFormGroup();
  }

  /**
   * create FormGroup with no values
   */
  createFormGroup() {
    this.actionForm = new FormGroup({
      manHoursUsed: new FormControl(null, Validators.required),
    });
  }

  /**
   * validate form
   */
  onSubmit() {
    if (this.actionForm.valid) {
      const job: Job = {
        id: this.data,
        manHoursUsed: this.actionForm.get('manHoursUsed')?.value,
      };
      this.closeAction(job);
    }
  }

  /**
   * submit job action to close to API
   * @param {Job} job job action to be closed
   */
  closeAction(job: Job) {
    this.jobService.closeJobAction(job).subscribe({
      next: () => {
        this.dialogRef.close();
        this.alertService.displaySuccess('Closed job action: ' + job.id);
      },
      error: (err: HttpErrorResponse) => {
        this.alertService.displayError(err.error);
      },
    });
  }
}
