import { Component, Inject, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Job } from 'src/app/interface/Job';
import { AlertService } from 'src/app/service/alert.service';
import { JobService } from 'src/app/service/job.service';

@Component({
  selector: 'app-close-job',
  templateUrl: './close-job.component.html',
  styleUrls: ['./close-job.component.css'],
})
export class CloseJobComponent implements OnInit {
  jobForm!: FormGroup;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: Job,
    private jobService: JobService,
    private dialogRef: MatDialogRef<CloseJobComponent>,
    private alertService: AlertService
  ) {}

  ngOnInit(): void {
    this.createFormGroup();
    console.log(this.data);
  }

  /**
   * create FormGroup with no values
   */
  createFormGroup() {
    this.jobForm = new FormGroup({
      diagnosticReport: new FormControl(null, Validators.required),
    });
  }

  /**
   * validate form
   */
  onSubmit() {
    if (this.jobForm.valid) {
      const job: Job = {
        jobId: this.data.id,
        diagnosticReport: this.jobForm.get('diagnosticReport')?.value,
      };
      this.closeJob(job);
    }
  }

  /**
   * submit job to close to API
   * @param {Job} job job to be closed
   */
  closeJob(job: Job) {
    this.jobService.closeJob(job).subscribe({
      next: () => {
        this.dialogRef.close();
        this.alertService.displaySuccess(
          'Closed job: ' + this.data.ticketTitle
        );
      },
      error: (err) => {
        this.alertService.displayError('Please try again');
      },
    });
  }
}
