import { FileService } from './../../../service/file.service';
import { AlertService } from './../../../service/alert.service';
import { Component, Inject, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { CustomErrorStateMatcher } from 'src/app/CustomErrorStateMatcher';
import { Company } from 'src/app/interface/Company';
import { CompanyService } from 'src/app/service/company.service';

@Component({
  selector: 'app-update-company',
  templateUrl: './update-company.component.html',
  styleUrls: ['./update-company.component.css'],
})
export class UpdateCompanyComponent implements OnInit {
  matcher = new CustomErrorStateMatcher();
  companyForm!: FormGroup;
  dataLoaded: Promise<boolean> = Promise.resolve(false);
  hasImage: boolean = false;
  imageLoading: boolean;
  image = new Array();
  type: string = '';

  private uploadedImage: File;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private companyService: CompanyService,
    private dialogRef: MatDialogRef<UpdateCompanyComponent>,
    private alertService: AlertService,
    private fileService: FileService
  ) {}

  ngOnInit(): void {
    this.checkMode();
  }

  /**
   * check whether user is creating or updating company
   */
  checkMode() {
    this.type = this.data.type;
    if (this.type == 'Create') {
      this.createMode();
    } else if (this.type == 'Edit') {
      this.editMode();
    }
  }

  /**
   * create FormGroup with no values
   */
  createMode() {
    this.companyForm = new FormGroup({
      name: new FormControl(null, Validators.required),
      description: new FormControl(null, Validators.required),
      location: new FormControl(null, Validators.required),
      contactName1: new FormControl(null),
      contactNo1: new FormControl(null, [
        Validators.pattern('^[0-9]*$'),
        Validators.minLength(8),
        Validators.maxLength(8),
      ]),
      contactEmail1: new FormControl(null, Validators.email),
      contactName2: new FormControl(null),
      contactNo2: new FormControl(null, [
        Validators.pattern('^[0-9]*$'),
        Validators.minLength(8),
        Validators.maxLength(8),
      ]),
      contactEmail2: new FormControl(null, Validators.email),
    });
    this.dataLoaded = Promise.resolve(true);
  }

  /**
   * create FormGroup with values
   */
  editMode() {
    this.companyForm = new FormGroup({
      name: new FormControl(this.data.company.name, Validators.required),
      description: new FormControl(
        this.data.company.description,
        Validators.required
      ),
      location: new FormControl(
        this.data.company.location,
        Validators.required
      ),
      contactName1: new FormControl(this.data.company.contactName1),
      contactNo1: new FormControl(this.data.company.contactNo1, [
        Validators.pattern('^[0-9]*$'),
        Validators.minLength(8),
        Validators.maxLength(8),
      ]),
      contactEmail1: new FormControl(
        this.data.company.contactEmail1,
        Validators.email
      ),
      contactName2: new FormControl(this.data.company.contactName2),
      contactNo2: new FormControl(this.data.company.contactNo2, [
        Validators.pattern('^[0-9]*$'),
        Validators.minLength(8),
        Validators.maxLength(8),
      ]),
      contactEmail2: new FormControl(
        this.data.company.contactEmail2,
        Validators.email
      ),
    });
    this.dataLoaded = Promise.resolve(true);
    if (this.data.company.logoPath) {
      this.hasImage = true;
      this.imageLoading = true;
      this.getImage();
    }
  }

  /**
   * get image using image path from database as blob. only for edit mode
   */
  getImage() {
    this.fileService
      .getFileAsBlob(this.data.company.name, this.data.company.logoPath)
      .subscribe({
        next: (image: Blob) => {
          this.blobToImageToDisplay(image);
        },
        error: (err) => {
          this.alertService.displayError('Failed to load image');
        },
      });
  }

  /**
   * convert blob to image to display
   * @param  {Blob} image image file
   */
  blobToImageToDisplay(image: Blob) {
    this.image.pop();
    this.uploadedImage = new File([image], 'image');
    let reader = new FileReader();
    reader.addEventListener(
      'load',
      () => {
        this.image.push(reader.result);
      },
      false
    );
    if (image) {
      reader.readAsDataURL(image);
    }
    this.imageLoading = false;
  }

  /**
   * validate image for further actions
   * @param  {any} event button event
   */
  onImageSelected(event: any) {
    this.uploadedImage = <File>event.target!.files[0];
    if (this.uploadedImage) {
      if (this.fileService.validateImageFile(this.uploadedImage)) {
        this.hasImage = true;
        this.displayImage(this.uploadedImage);
      }
    }
  }

  /**
   * insert image to display
   * @param  {File} file image file
   */
  displayImage(file: File) {
    this.image.pop();
    let reader = new FileReader();
    reader.addEventListener(
      'load',
      () => {
        this.image.push(reader.result);
      },
      false
    );
    if (file) {
      reader.readAsDataURL(file);
    }
  }

  /**
   * remove image
   */
  onDeleteImage() {
    this.image.pop();
    this.uploadedImage = null!;
    this.hasImage = false;
  }

  /**
   * validate form
   */
  onSubmit() {
    if (this.companyForm.valid) {
      const company: Company = {
        name: this.companyForm.get('name')?.value,
        oldName: this.data.company?.name ? this.data.company.name : null,
        location: this.companyForm.get('location')?.value,
        description: this.companyForm.get('description')?.value,
        contactName1: this.companyForm.get('contactName1')?.value,
        contactNo1: this.companyForm.get('contactNo1')?.value,
        contactEmail1: this.companyForm.get('contactEmail1')?.value,
        contactName2: this.companyForm.get('contactName2')?.value,
        contactNo2: this.companyForm.get('contactNo2')?.value,
        contactEmail2: this.companyForm.get('contactEmail2')?.value,
        logo: this.hasImage ? this.uploadedImage : null!,
      };
      this.createFormData(company);
    }
  }

  /**
   * create FormData from company object
   * @param  {Company} company company to be created
   */
  createFormData(company: Company) {
    const formData = new FormData();
    for (let key in company) {
      if (company[key as keyof Company] == null) {
        formData.append(key, '');
        continue;
      }
      formData.append(key, company[key as keyof Company]!);
    }
    if (this.type == 'Create') {
      this.createCompany(formData);
    } else if (this.type == 'Edit') {
      this.updateCompany(formData);
    }
  }

  /**
   * create company from formdata
   * @param  {FormData} formData company to be created
   */
  createCompany(formData: FormData) {
    this.companyService.createCompany(formData).subscribe({
      next: () => {
        this.dialogRef.close();
        this.alertService.displaySuccess(
          'Created company: ' + formData.get('name')
        );
      },
      error: (err) => {
        this.alertService.displayError('Please try again');
      },
    });
  }

  /**
   * submit company to API
   * @param  {FormData} formData company to be updated
   */
  updateCompany(formData: FormData) {
    this.companyService.updateCompany(formData).subscribe({
      next: () => {
        this.dialogRef.close();
        this.alertService.displaySuccess(
          'Updated company: ' + formData.get('name')
        );
      },
      error: (err) => {
        this.alertService.displayError('Please try again');
      },
    });
  }
}
