import { DateService } from './../../../service/date.service';
import { ContractService } from './../../../service/contract.service';
import { AlertService } from 'src/app/service/alert.service';
import { ProjectService } from 'src/app/service/project.service';
import { Project } from 'src/app/interface/Project';
import { Contract } from 'src/app/interface/Contract';
import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-update-contract',
  templateUrl: './update-contract.component.html',
  styleUrls: ['./update-contract.component.css'],
})
export class UpdateContractComponent implements OnInit {
  types: Contract[];
  projects: Project[];
  contractForm!: FormGroup;

  constructor(
    @Inject(MAT_DIALOG_DATA) public companyName: string,
    private dialogRef: MatDialogRef<UpdateContractComponent>,
    private projectService: ProjectService,
    private alertService: AlertService,
    private contractService: ContractService,
    private dateService: DateService
  ) {}

  ngOnInit(): void {
    this.getType();
    this.getProject();
    this.createFormGroup();
  }

  /**
   * create FormGroup with no values
   */
  createFormGroup() {
    this.contractForm = new FormGroup({
      project: new FormControl(null, Validators.required),
      type: new FormControl(null, Validators.required),
      totalManhours: new FormControl(null, Validators.required),
      description: new FormControl(null, Validators.required),
      startDate: new FormControl(
        { value: null, disabled: true },
        Validators.required
      ),
      endDate: new FormControl(
        { value: null, disabled: true },
        Validators.required
      ),
    });
  }

  /**
   * get contract types available
   */
  getType() {
    this.contractService.getContractType().subscribe({
      next: (res) => {
        this.types = res;
      },
      error: (err) => {
        this.alertService.displayError('Failed to get types.');
      },
    });
  }

  /**
   * get project to display in table
   */
  getProject() {
    this.projectService.getProject().subscribe({
      next: (res) => {
        this.projects = res;
      },
      error: (err) => {
        this.alertService.displayError('Failed to get projects');
      },
    });
  }

  /**
   * validate form
   */
  onSubmit() {
    const contract: Contract = {
      companyName: this.companyName,
      projectId: this.contractForm.get('project')?.value,
      typeName: this.contractForm.get('type')?.value,
      manhoursTotal: this.contractForm.get('totalManhours')?.value,
      details: this.contractForm.get('description')?.value,
      startDate: this.dateService.transformDate(
        this.contractForm.get('startDate')?.value
      ),
      endDate: this.dateService.transformDate(
        this.contractForm.get('endDate')?.value
      ),
    };
    console.log(contract);
    this.createContract(contract);
  }

  /**
   * submit action to API
   * @param  {Contract} contract contract to be submitted
   */
  createContract(contract: Contract) {
    this.contractService.createContract(contract).subscribe({
      next: () => {
        this.alertService.displaySuccess('Contract successfully created');
        this.dialogRef.close(); // if valid and complete den close
      },
      error: (err) => {
        this.alertService.displayError(err.error);
      },
    });
  }
}
