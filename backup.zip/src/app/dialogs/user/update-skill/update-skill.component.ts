import { Skill } from './../../../interface/Skill';
import { AlertService } from './../../../service/alert.service';
import { StaffService } from './../../../service/staff.service';
import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { User } from 'src/app/interface/User';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-update-skill',
  templateUrl: './update-skill.component.html',
  styleUrls: ['./update-skill.component.css'],
})
export class UpdateSkillComponent implements OnInit {
  skills: Skill[];
  skillForm!: FormGroup;
  chips = new Array();

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: User,
    private staffService: StaffService,
    private alertService: AlertService,
    private dialogRef: MatDialogRef<UpdateSkillComponent>
  ) {}

  ngOnInit(): void {
    this.createFormGroup();
    this.getSkill();
    this.getCurrentSkill();
  }

  /**
   * create FormGroup with values
   */
  createFormGroup() {
    this.skillForm = new FormGroup({
      skill: new FormControl(null),
    });
    this.skillForm.get('skill')?.valueChanges.subscribe((skill) => {
      this.addChip(skill);
    });
  }

  /**
   * get current skills that users have
   */
  getCurrentSkill() {
    this.staffService.getSkillByUser(this.data.username!).subscribe({
      next: (res) => {
        res.forEach((skill: Skill) => {
          this.chips.push(skill.skillName);
        });
      },
      error: () => {
        this.alertService.displayError('Failed to retrieve skill');
      },
    });
  }

  /**
   * get skill
   */
  getSkill() {
    this.staffService.getSkill().subscribe({
      next: (res) => {
        this.skills = res;
      },
      error: (err) => {
        this.alertService.displayError('Unable to retrive skill');
      },
    });
  }

  /**
   * add skill to list of chips
   * @param {string} skill skill to be added to chip
   */
  addChip(skill: string) {
    this.chips.push(skill);
  }

  /**
   * remove skill from list of chips
   * @param {string} skill skill to be removed from chip
   */
  removeChip(skill: string) {
    this.chips.forEach((value, index) => {
      if (value == skill) {
        this.chips.splice(index, 1);
      }
    });
  }

  /**
   * check skill from list of chips
   * @param {string} skill skill to be checked from chip
   * @return {boolean} true to disable, false to enable
   */
  checkChip(skill: string): boolean {
    let disable: boolean = false;
    this.chips.forEach((value) => {
      if (value == skill) {
        disable = true;
      }
    });
    return disable;
  }

  /**
   * validate input
   * make an array of all the skills
   */
  onSubmit() {
    let addedSkill: Skill[] = [];
    this.chips.forEach((skill) => {
      addedSkill.push({ staffName: this.data.username, skillName: skill });
    });
    if (this.chips.length == 0) {
      addedSkill.push({ staffName: this.data.username, skillName: '' });
    }
    this.linkSkill(addedSkill);
  }

  /**
   * send skills to api
   * @param {Skill[]} skill skill to be added
   */
  linkSkill(skill: Skill[]) {
    this.staffService.addSkill(skill).subscribe({
      next: () => {
        this.dialogRef.close();
        this.alertService.displaySuccess('Skill updated');
      },
      error: () => {
        this.alertService.displayError('Please try again');
      },
    });
  }
}
