import { AlertService } from '../../../service/alert.service';
import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { User } from 'src/app/interface/User';
import { UserService } from 'src/app/service/user.service';
import { CustomErrorStateMatcher } from 'src/app/CustomErrorStateMatcher';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrls: ['./update-profile.component.css'],
})
export class UpdateProfileComponent implements OnInit {
  matcher = new CustomErrorStateMatcher();
  userForm!: FormGroup;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: User,
    private userService: UserService,
    private dialogRef: MatDialogRef<UpdateProfileComponent>,
    private alertService: AlertService
  ) {}

  ngOnInit(): void {
    this.createFormGroup();
  }

  /**
   * create FormGroup
   */
  createFormGroup() {
    this.userForm = new FormGroup({
      phoneNumber: new FormControl(this.data.phoneNumber, [
        Validators.pattern('^[0-9]*$'),
        Validators.minLength(8),
        Validators.maxLength(8),
      ]),
      email: new FormControl(this.data.email, [
        Validators.required,
        Validators.email,
      ]),
    });
  }

  /**
   * validate form to update
   */
  onSave() {
    if (this.userForm.valid) {
      const user: User = {
        phoneNumber: this.userForm.get('phoneNumber')?.value,
        email: this.userForm.get('email')?.value,
      };
      this.updateUser(user);
    }
  }

  /**
   * submit updated user to API
   * @param  {User} user user to be submitted
   */
  updateUser(user: User) {
    this.userService.updateUserInfo(user).subscribe({
      next: () => {
        this.dialogRef.close();
        this.alertService.displaySuccess('Updated user: ' + this.data.username);
      },
      error: (err) => {
        this.alertService.displayError('Please try again');
      },
    });
  }
}
