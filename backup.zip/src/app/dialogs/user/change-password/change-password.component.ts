import { AlertService } from '../../../service/alert.service';
import { Password } from '../../../interface/Password';
import { UserService } from '../../../service/user.service';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css'],
})
export class ChangePasswordComponent implements OnInit {
  passwordForm!: FormGroup;

  constructor(
    private userService: UserService,
    private dialogRef: MatDialogRef<ChangePasswordComponent>,
    private alertService: AlertService
  ) {}

  ngOnInit(): void {
    this.createFormGroup();
  }

  /**
   * create FormGroup
   */
  createFormGroup() {
    this.passwordForm = new FormGroup({
      oldPass: new FormControl('', Validators.required),
      newPass: new FormControl('', Validators.required),
      newPass2: new FormControl('', Validators.required),
    });
  }

  /**
   * validate inputs
   */
  onSubmit() {
    if (this.passwordForm.valid) {
      const password: Password = {
        oldPassword: this.passwordForm.get('oldPass')?.value,
        newPassword: this.passwordForm.get('newPass')?.value,
        confirmNewPassword: this.passwordForm.get('newPass2')?.value,
      };
      this.changePassword(password);
    }
  }

  /**
   * submit password to API
   * @param  {Password} password password to be submitted
   */
  changePassword(password: Password) {
    this.userService.changePassword(password).subscribe({
      next: () => {
        this.alertService.displaySuccess('Password successfully changed');
        this.dialogRef.close(); // if valid and complete den close
      },
      error: (err) => {
        this.alertService.displayError(err.error);
      },
    });
  }
}
