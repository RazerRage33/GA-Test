import { AlertService } from './../../../service/alert.service';
import { FileService } from './../../../service/file.service';
import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Ticket } from 'src/app/interface/Ticket';

@Component({
  selector: 'app-view-ticket',
  templateUrl: './view-ticket.component.html',
  styleUrls: ['./view-ticket.component.css'],
})
export class ViewTicketComponent implements OnInit {
  hasImage: boolean;
  dataLoaded: Promise<boolean> = Promise.resolve(false);
  images = new Array();

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: Ticket,
    private fileService: FileService,
    private alertService: AlertService
  ) {}

  ngOnInit(): void {
    console.log(this.data);
    this.getImage();
  }

  /**
   * get image using image path from database
   */
  getImage() {
    if (this.data.imageNameWithExtension1) {
      this.fileService
        .getFileAsBlob(
          this.data.companyName!,
          this.data.imageNameWithExtension1
        )
        .subscribe({
          next: (image: Blob) => {
            this.hasImage = true;
            this.blobToImageToDisplay(image);
          },
          error: (err) => {
            this.alertService.displayError('Failed to load image');
          },
        });
    } else {
      this.hasImage = false;
      this.dataLoaded = Promise.resolve(true);
    }
    if (this.data.imageNameWithExtension2) {
      this.fileService
        .getFileAsBlob(
          this.data.companyName!,
          this.data.imageNameWithExtension2
        )
        .subscribe({
          next: (image: Blob) => {
            this.hasImage = true;
            this.blobToImageToDisplay(image);
          },
          error: (err) => {
            this.alertService.displayError('Failed to load image');
          },
        });
    }
  }

  /**
   * convert blob to image to display
   * @param  {Blob} image image file
   */
  blobToImageToDisplay(image: Blob) {
    let reader = new FileReader();
    reader.addEventListener(
      'load',
      () => {
        this.images.push(reader.result);
      },
      false
    );
    if (image) {
      reader.readAsDataURL(image);
    }
    this.dataLoaded = Promise.resolve(true);
  }

  /**
   * get file using file path from database
   */
  downloadFile() {
    if (this.data.fileNameWithExtension) {
      this.fileService
        .getFileAsBlob(this.data.companyName!, this.data.fileNameWithExtension)
        .subscribe({
          next: (res) => {
            let FileSaver = require('file-saver');
            FileSaver.saveAs(res, this.data.fileNameWithExtension);
          },
          error: (err) => {
            this.alertService.displayError('Failed to load image');
          },
        });
    }
  }

  /**
   * get file name from filepath
   * @param { string } file file path
   * @return { string } file name
   */
  getFileName(file: string) {
    return file.replace('Documents\\', '');
  }
}
