import { ProjectService } from 'src/app/service/project.service';
import { TicketService } from './../../../service/ticket.service';
import { Project } from 'src/app/interface/Project';
import { Ticket } from './../../../interface/Ticket';
import { AlertService } from './../../../service/alert.service';
import { FileService } from './../../../service/file.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-update-ticket',
  templateUrl: './update-ticket.component.html',
  styleUrls: ['./update-ticket.component.css'],
})
export class UpdateTicketComponent implements OnInit {
  hasImage: boolean;
  images = new Array();
  ticketForm: FormGroup;
  categories: Ticket[];
  projects: Project[];
  uploadedFile: File;

  private uploadedImage1: File;
  private uploadedImage2: File;
  constructor(
    private fileService: FileService,
    private alertService: AlertService,
    private ticketService: TicketService,
    private projectService: ProjectService,
    private dialogRef: MatDialogRef<UpdateTicketComponent>
  ) {}

  ngOnInit(): void {
    this.getCategory();
    this.getProject();
    this.createFormGroup();
  }

  /**
   * get category
   */
  getCategory() {
    this.ticketService.getCategory().subscribe({
      next: (res) => {
        this.categories = res;
      },
      error: (err) => {
        this.alertService.displayError('Unable to retrive category');
      },
    });
  }

  /**
   * get project
   */
  getProject() {
    this.projectService.getProjectByCompany().subscribe({
      next: (res) => {
        this.projects = res;
      },
      error: (err) => {
        this.alertService.displayError('Unable to retrive project');
      },
    });
  }

  /**
   * create FormGroup with no values
   */
  createFormGroup() {
    this.ticketForm = new FormGroup({
      project: new FormControl(null, Validators.required),
      category: new FormControl(null, Validators.required),
      title: new FormControl(null, Validators.required),
      description: new FormControl(null, Validators.required),
    });
  }

  /**
   * validate image for further actions
   * @param  {any} event button event
   */
  onImageSelected(event: any) {
    let numberOfImage: number = event.target!.files.length; // number of images
    if (numberOfImage) {
      if (numberOfImage > 2) {
        this.alertService.displayInfo('First 2 images selected');
      }
      this.uploadedImage1 = <File>event.target!.files[0];
      if (this.fileService.validateImageFile(this.uploadedImage1)) {
        //remove first image
        if (this.images.length == 2) {
          this.images.shift();
        }
        this.hasImage = true;
        this.displayImage(this.uploadedImage1);
        if (numberOfImage > 1) {
          // if theres already 2 images, remove both
          if (this.images.length == 1) {
            this.images.shift();
          }
          this.uploadedImage2 = <File>event.target!.files[1];
          if (this.fileService.validateImageFile(this.uploadedImage2)) {
            this.displayImage(this.uploadedImage2);
          }
        }
      }
    }
  }

  /**
   * validate file for further actions
   * @param  {any} event button event
   */
  onFileSelected(event: any) {
    this.uploadedFile = <File>event.target!.files[0];
  }

  /**
   * remove image
   */
  onDeleteImage() {
    this.uploadedImage1 = null!;
    this.uploadedImage2 = null!;
    this.hasImage = false;
    this.images.splice(0);
  }

  /**
   * insert image to display
   * @param  {File} file image file
   */
  displayImage(file: File) {
    let reader = new FileReader();
    reader.addEventListener(
      'load',
      () => {
        this.images.push(reader.result);
      },
      false
    );
    if (file) {
      reader.readAsDataURL(file);
    }
  }

  /**
   * validate form
   */
  onSubmit() {
    const ticket: Ticket = {
      projectName: this.ticketForm.get('project')?.value,
      categoryName: this.ticketForm.get('category')?.value,
      title: this.ticketForm.get('title')?.value,
      description: this.ticketForm.get('description')?.value,
      file: this.uploadedFile ? this.uploadedFile : null!,
      image1: this.uploadedImage1 ? this.uploadedImage1 : null!,
      image2: this.uploadedImage2 ? this.uploadedImage2 : null!,
    };
    this.createFormData(ticket);
  }

  /**
   * create FormData from ticket object
   * @param  {Ticket} ticket ticket to be created
   */
  createFormData(ticket: Ticket) {
    const formData = new FormData();
    for (let key in ticket) {
      if (ticket[key as keyof Ticket] == null) {
        formData.append(key, '');
        continue;
      }
      formData.append(key, ticket[key as keyof Ticket]!);
    }
    this.createTicket(formData);
  }

  /**
   * create ticket from formdata
   * @param  {FormData} formData ticket to be created
   */
  createTicket(formData: FormData) {
    this.ticketService.createTicket(formData).subscribe({
      next: () => {
        this.dialogRef.close();
        this.alertService.displaySuccess(
          'Created ticket: ' + formData.get('title')
        );
      },
      error: (err) => {
        this.alertService.displayError('Please try again');
      },
    });
  }
}
