import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ROUTE } from 'src/app/APP_CONFIG';
import { Password } from 'src/app/interface/Password';
import { AlertService } from 'src/app/service/alert.service';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css'],
})
export class ResetPasswordComponent implements OnInit {
  passwordForm!: FormGroup;
  hidePassword: boolean = true;
  hideConfirmPassword: boolean = true;
  resetted: boolean;
  private token: string;

  constructor(
    private userService: UserService,
    private alertService: AlertService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.getQueryParams();
    this.createFormGroup();
  }

  /**
   * create FormGroup
   */
  createFormGroup() {
    this.passwordForm = new FormGroup({
      newPassword: new FormControl(null, Validators.required),
      confirmNewPassword: new FormControl(null, Validators.required),
    });
  }

  /**
   * get token from url
   */
  getQueryParams() {
    this.route.queryParams.subscribe((params: Password) => {
      console.log(params);
      if (params.token) {
        this.token = params.token;
      } else {
        this.onBack();
        this.alertService.displayWarning('Please re-enter link');
      }
    });
  }

  /**
   * validate form
   */
  onSubmit() {
    if (this.passwordForm.valid) {
      const password: Password = {
        token: this.token,
        newPassword: this.passwordForm.get('newPassword')?.value,
        confirmNewPassword: this.passwordForm.get('confirmNewPassword')?.value,
      };
      this.resetPassword(password);
    }
  }

  /**
   * go back login page
   */
  onBack() {
    this.router.navigate([ROUTE.LOGIN]);
  }

  /**
   * send reset password request to api
   * @param {Password} password password to be sent
   */
  resetPassword(password: Password) {
    this.userService.resetPassword(password).subscribe({
      next: () => {
        this.resetted = true;
        this.alertService.displaySuccess('Password resetted');
      },
      error: (err) => {
        this.onBack();
        this.alertService.displayError('Reset link has expired.');
      },
    });
  }
}
