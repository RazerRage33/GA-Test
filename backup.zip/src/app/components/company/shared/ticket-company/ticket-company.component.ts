import { FileService } from './../../../../service/file.service';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Table } from 'primeng/table';
import { TABLE_STATUS } from 'src/app/APP_CONFIG';
import { UpdateTicketComponent } from 'src/app/dialogs/ticket/update-ticket/update-ticket.component';
import { ViewTicketComponent } from 'src/app/dialogs/ticket/view-ticket/view-ticket.component';
import { Ticket } from 'src/app/interface/Ticket';
import { AlertService } from 'src/app/service/alert.service';
import { TicketService } from 'src/app/service/ticket.service';

@Component({
  selector: 'app-ticket-company',
  templateUrl: './ticket-company.component.html',
  styleUrls: ['./ticket-company.component.css'],
})
export class TicketCompanyComponent implements OnInit {
  @ViewChild('dt') dt: Table | undefined;
  loading: boolean = true;
  tickets!: Ticket[];
  filterColumn: string[] = [
    'title',
    'projectName',
    'categoryName',
    'requestedOn',
    'statusName',
  ];

  ticketForm: FormGroup;
  tableStatus: string[] = TABLE_STATUS;

  constructor(
    private ticketService: TicketService,
    private dialog: MatDialog,
    private alertService: AlertService,
    private fileService: FileService
  ) {}

  ngOnInit(): void {
    this.createFormGroup();
    this.getTicket();
  }

  /**
   * create FormGroup. one for staff, one for company
   */
  createFormGroup() {
    this.ticketForm = new FormGroup({
      status: new FormControl(this.tableStatus[0]),
    });

    this.ticketForm.valueChanges.subscribe(() => {
      this.getTicket();
    });
  }

  /**
   * get ticket to display in table
   */
  getTicket() {
    this.loading = true;
    let statusType: string = this.ticketForm.get('status')?.value;
    this.ticketService.getTicket(statusType).subscribe({
      next: (res) => {
        this.loading = false;
        this.tickets = res;
      },
      error: (err) => {
        this.alertService.displayError('Failed to get tickets');
      },
    });
  }

  /**
   * filter search
   */
  applyFilter($event: any, stringVal: string) {
    this.dt!.filterGlobal(($event.target as HTMLInputElement).value, stringVal);
  }

  /**
   * open dialog to view ticket
   */
  onViewTicket(ticket: Ticket) {
    this.dialog.open(ViewTicketComponent, { data: ticket });
  }

  /**
   * open dialog to create ticket
   */
  onCreateTicket() {
    let dialogRef = this.dialog.open(UpdateTicketComponent);
    dialogRef.afterClosed().subscribe(() => {
      this.getTicket();
    });
  }

  /**
   * get file using file path from database
   */
  onDownloadReport(row: Ticket) {
    if (row.reportPath) {
      this.fileService
        .getFileAsBlob(row.companyName!, row.reportPath)
        .subscribe({
          next: (res) => {
            let FileSaver = require('file-saver');
            FileSaver.saveAs(res, row.reportPath);
          },
          error: (err) => {
            this.alertService.displayError('Failed to download report');
          },
        });
    }
  }
}
