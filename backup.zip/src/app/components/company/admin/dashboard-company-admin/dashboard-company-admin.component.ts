import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-company-admin',
  templateUrl: './dashboard-company-admin.component.html',
  styleUrls: ['./dashboard-company-admin.component.css']
})
export class DashboardCompanyAdminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
