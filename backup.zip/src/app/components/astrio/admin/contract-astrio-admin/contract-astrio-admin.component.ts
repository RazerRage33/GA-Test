import { UpdateContractComponent } from './../../../../dialogs/contract/update-contract/update-contract.component';
import { ViewContractComponent } from './../../../../dialogs/contract/view-contract/view-contract.component';
import { ContractService } from './../../../../service/contract.service';
import { Contract } from 'src/app/interface/Contract';
import { AlertService } from 'src/app/service/alert.service';
import { Company } from 'src/app/interface/Company';
import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ROUTE } from 'src/app/APP_CONFIG';
import { Table } from 'primeng/table';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-contract-astrio-admin',
  templateUrl: './contract-astrio-admin.component.html',
  styleUrls: ['./contract-astrio-admin.component.css'],
})
export class ContractAstrioAdminComponent implements OnInit {
  companyName: string;
  @ViewChild('dt') dt: Table | undefined;
  loading: boolean = true;
  contracts!: Contract[];
  filterColumn: string[] = [
    'projectName',
    'typeName',
    'manhoursRemaining',
    'startDate',
    'endDate',
  ];

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private alertService: AlertService,
    private contractService: ContractService,
    private dialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.getQueryParams();
  }

  /**
   * get token from url
   */
  getQueryParams() {
    this.route.queryParams.subscribe((params: Company) => {
      if (params.name) {
        this.companyName = params.name;
        this.getContract();
      } else {
        this.onBack();
        this.alertService.displayError('Please re-enter page');
      }
    });
  }

  /**
   * open page to view job action
   */
  onBack() {
    this.router.navigate(['../../' + ROUTE.COMPANY], {
      relativeTo: this.route,
    });
  }

  /**
   * filter search
   */
  applyFilter($event: any, stringVal: string) {
    this.dt!.filterGlobal(($event.target as HTMLInputElement).value, stringVal);
  }

  /**
   * get contracts to display in table
   */
  getContract() {
    this.loading = true;
    this.contractService.getContract(this.companyName).subscribe({
      next: (res) => {
        this.loading = false;
        this.contracts = res;
      },
      error: (err) => {
        this.alertService.displayError('Failed to get contracts');
      },
    });
  }

  /**
   * open dialog to create company
   */
  onAddProject() {
    let dialogRef = this.dialog.open(UpdateContractComponent, {
      data: this.companyName,
    });
    dialogRef.afterClosed().subscribe(() => {
      this.getContract();
    });
  }

  /**
   * open page to view project with contract
   */
  onViewProject(project: Contract) {
    this.dialog.open(ViewContractComponent, { data: project });
  }
}
