import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-astrio-admin',
  templateUrl: './dashboard-astrio-admin.component.html',
  styleUrls: ['./dashboard-astrio-admin.component.css']
})
export class DashboardAstrioAdminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void { 
  }

}
