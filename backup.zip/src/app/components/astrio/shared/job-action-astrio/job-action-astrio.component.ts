import { CloseActionComponent } from './../../../../dialogs/job/close-action/close-action.component';
import { ViewActionComponent } from '../../../../dialogs/job/view-action/view-action.component';
import { UpdateActionComponent } from '../../../../dialogs/job/update-action/update-action.component';
import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Table } from 'primeng/table';
import { ROUTE, TABLE_STATUS } from 'src/app/APP_CONFIG';
import { Job } from 'src/app/interface/Job';
import { AlertService } from 'src/app/service/alert.service';
import { JobService } from 'src/app/service/job.service';
import { MatDialog } from '@angular/material/dialog';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-job-action-astrio',
  templateUrl: './job-action-astrio.component.html',
  styleUrls: ['./job-action-astrio.component.css'],
})
export class JobActionAstrioComponent implements OnInit {
  @ViewChild('dt') dt: Table | undefined;
  loading: boolean = true;
  jobActions!: Job[];
  filterColumn: string[] = ['staffName', 'manHoursUsed', 'createdBy'];
  jobForm: FormGroup;
  tableStatus: string[] = TABLE_STATUS;
  ticketTitle: string;

  private id: string;

  constructor(
    private jobService: JobService,
    private alertService: AlertService,
    private router: Router,
    private route: ActivatedRoute,
    public dialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.createFormGroup();
    this.getQueryParams();
  }

  /**
   * get token from url
   */
  getQueryParams() {
    this.route.queryParams.subscribe((params: Job) => {
      if (params.id && params.ticketTitle) {
        this.ticketTitle = params.ticketTitle;
        this.id = params.id;
        this.getJobAction();
      } else {
        this.onBack();
        this.alertService.displayError('Please re-enter page');
      }
    });
  }

  /**
   * create FormGroup. one for staff, one for company
   */
  createFormGroup() {
    this.jobForm = new FormGroup({
      status: new FormControl(this.tableStatus[0]),
    });

    this.jobForm.valueChanges.subscribe(() => {
      this.getJobAction();
    });
  }

  /**
   * get jobs to display in table
   */
  getJobAction() {
    this.loading = true;
    const jobQuery: Job = {
      jobId: this.id,
      status: this.jobForm.get('status')?.value,
    };
    this.jobService.getJobAction(jobQuery).subscribe({
      next: (res) => {
        this.loading = false;
        this.jobActions = res;
      },
      error: (err) => {
        this.alertService.displayError('Failed to get job actions');
      },
    });
  }

  /**
   * filter search
   */
  applyFilter($event: any, stringVal: string) {
    this.dt!.filterGlobal(($event.target as HTMLInputElement).value, stringVal);
  }

  /**
   * open page to view job action
   */
  onViewJobAction(job: Job) {
    this.dialog.open(ViewActionComponent, { data: job });
  }

  /**
   * open page to view job action
   */
  onBack() {
    this.router.navigate(['../../' + ROUTE.JOB], {
      relativeTo: this.route,
    });
  }

  /**
   * open dialog to create job action
   */
  onCreateJobAction() {
    let dialogRef = this.dialog.open(UpdateActionComponent, { data: this.id });
    dialogRef.afterClosed().subscribe(() => {
      this.getJobAction();
    });
  }

  /**
   * open dialog to close job action
   */
  onCloseJobAction(job: Job) {
    let dialogRef = this.dialog.open(CloseActionComponent, { data: job.id });
    dialogRef.afterClosed().subscribe(() => {
      this.getJobAction();
    });
  }
}
