import { Ticket } from 'src/app/interface/Ticket';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { API_URL, HTTP_OPTION } from '../APP_CONFIG';

@Injectable({
  providedIn: 'root',
})
export class TicketService {
  constructor(private http: HttpClient) {}

  /**
   * get ticket from API
   * @param { string } statusType status type to query
   * @return {any}  ticket observable
   */
  getTicket(statusType: string): Observable<any> {
    return this.http.get(API_URL + 'Ticket/' + statusType, HTTP_OPTION);
  }

  /**
   * get ticket count of specified status from API
   * @return {any}  string
   */
  getTicketCount(): Observable<any> {
    return this.http.get(API_URL + 'Ticket/GetTicketCount', HTTP_OPTION);
  }

  /**
   * get ticket category from API
   * @return {any}  ticket category observable
   */
  getCategory(): Observable<any> {
    return this.http.get(API_URL + 'Ticket/TicketCategory', HTTP_OPTION);
  }

  /**
   * create ticket
   * @param {FormData} ticket ticket to be created
   * @return {any} response
   */
  createTicket(ticket: FormData): Observable<any> {
    return this.http.post(API_URL + 'Ticket/Create', ticket, HTTP_OPTION);
  }

  /**
   * process ticket
   * @param {Ticket} ticket ticket to be processed
   * @return {any} response
   */
  processTicket(ticket: Ticket): Observable<any> {
    return this.http.post(
      API_URL + 'Ticket/ProcessTicket',
      ticket,
      HTTP_OPTION
    );
  }
}
