import { UserService } from 'src/app/service/user.service';
import { Router } from '@angular/router';
import { Menu } from './../interface/Menu';
import { AlertService } from './alert.service';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { User } from '../interface/User';
import { API_URL, HTTP_OPTION, ROUTE } from '../APP_CONFIG';

import { EMPTY } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private loggedIn = new BehaviorSubject<boolean>(false);
  private homePage = new BehaviorSubject<string>('');

  constructor(
    private http: HttpClient,
    private alertService: AlertService,
    private router: Router,
    private userService: UserService
  ) {
    this.isRefreshed();
  }

  /**
   * getter for whether user is logged in
   * @return — observable true for logged in or false for not logged in
   */
  get isLoggedIn() {
    return this.loggedIn.asObservable();
  }

  /**
   * set whether user is logged in
   * @param value true for logged in or false for not logged in
   */
  set setLoggedIn(value: boolean) {
    this.loggedIn.next(value);
  }

  /**
   * getter user's home page
   * @return — string home page link
   */
  get userHomePage() {
    return this.homePage.getValue();
  }

  /**
   * set user's home page
   * @param value home page link
   */
  set setUserHomePage(value: string) {
    this.homePage.next(value);
  }

  /**
   * reload variables if refreshed
   */
  isRefreshed() {
    this.checkLogin();
    this.checkHomePage();
  }

  /**
   * check whether user is logged in on refresh
   */
  checkLogin() {
    if (localStorage.getItem('user')) {
      this.loggedIn.next(true);
    }
  }

  /**
   * check whether homepge link is present
   */
  checkHomePage() {
    if (localStorage.getItem('user')) {
      let user: User = this.userService.getUserFromLocalStorage();
      if (user.homePage) {
        this.homePage.next(user.homePage);
      }
    }
  }

  /**
   * submit user details to API
   * @param  {User} user user details to submit
   */
  validateUser(user: User): Observable<any> {
    // return this.http.post(API_URL + 'Authenticate/login', user, httpOption);
    return this.http.post(API_URL + 'Auth/Login', user, HTTP_OPTION);
  }

  /**
   * refresh access token
   */
  refreshCookie() {
    return this.http.get(API_URL + 'Auth/Refresh', HTTP_OPTION);
  }

  /**
   * get all menu items
   * only ones available to user
   * @return {Menu[]}  all menu item
   */
  getMenu(): Observable<Menu[]> {
    return this.http.get<Menu[]>(API_URL + 'Menu', HTTP_OPTION);
  }

  /**
   * check if user have access to current page
   * true for have access, false for no access
   * @param {string} routePath path to check for
   * @return {string}  boolean value
   */
  haveAccess(routePath: string) {
    return this.http.post(
      API_URL + 'Menu/MenuAuthentication',
      { link: routePath },
      {
        withCredentials: true,
        responseType: 'text',
      }
    );
  }

  /**
   * logout of website
   * clear local storage
   * clear cookies
   */
  logout(): Observable<any> {
    let isLoggedIn: boolean = this.loggedIn.getValue();
    if (isLoggedIn) {
      this.loggedIn.next(false);
      localStorage.clear();
      this.router.navigate([ROUTE.LOGIN]);
      this.alertService.displayInfo('Logged out');
      return this.http.post(API_URL + 'Auth/Logout', null, HTTP_OPTION);
    } else {
      return EMPTY;
    }
  }
}
