import { Ticket } from './../interface/Ticket';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API_URL, HTTP_OPTION } from '../APP_CONFIG';
import { Observable } from 'rxjs';
import { Job } from '../interface/Job';

@Injectable({
  providedIn: 'root',
})
export class JobService {
  constructor(private http: HttpClient) {}

  /**
   * get all job from database
   * @param { string } statusType either ongoing or completed
   * @return {Job[]}  all job
   */
  getJob(statusType: string): Observable<Job[]> {
    return this.http.get<Job[]>(API_URL + 'Job/' + statusType, HTTP_OPTION);
  }

  /**
   * get all job from database
   * @param {Job} jobQuery job id and status type to query
   * @return {Job[]}  all job action
   */
  getJobAction(jobQuery: Job): Observable<Job[]> {
    return this.http.post<Job[]>(
      API_URL + 'JobAction/GetJobActionByJobId',
      jobQuery,
      HTTP_OPTION
    );
  }

  /**
   * create job
   * @param {Ticket} ticket to start job
   */
  createJob(ticket: Ticket) {
    return this.http.post<Ticket>(
      API_URL + 'Job/Create',
      { ticketId: ticket.id },
      HTTP_OPTION
    );
  }

  /**
   * create job action
   * @param {Ticket} ticket to start job action
   */
  createJobAction(ticket: Ticket) {
    return this.http.post<Ticket>(
      API_URL + 'JobAction/Create',
      ticket,
      HTTP_OPTION
    );
  }

  /**
   * close job
   * @param {Job} job job to close
   */
  closeJob(job: Job) {
    return this.http.post<Job>(API_URL + 'Job/Close', job, HTTP_OPTION);
  }

  /**
   * close job action
   * @param {Job} job job action to close
   */
  closeJobAction(job: Job) {
    return this.http.post<Job>(API_URL + 'JobAction/Close', job, HTTP_OPTION);
  }
}
