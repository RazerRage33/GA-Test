import { AlertService } from './alert.service';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { API_URL, IMAGE_FILE_TYPE } from '../APP_CONFIG';

@Injectable({
  providedIn: 'root',
})
export class FileService {
  constructor(private http: HttpClient, private alertService: AlertService) {}

  /**
   * get file from database
   * @param {string} companyName company name
   * @param {string} filePath file path
   * @return {Observable<Blob>}  file as blob
   */
  getFileAsBlob(companyName: string, filePath: string): Observable<Blob> {
    return this.http.get(
      API_URL + 'File/' + encodeURIComponent(companyName + '\\' + filePath),
      {
        withCredentials: true,
        responseType: 'blob',
      }
    );
  }

  /**
   * check whether file is a image
   * @param  {File} file file to be checked
   * @return  {boolean} returns true if valid, false if invalid
   */
  validateImageFile(file: File): boolean {
    if (IMAGE_FILE_TYPE.includes(file.type)) {
      return true;
    } else {
      this.alertService.displayWarning('Invalid image file!');
      return false;
    }
  }

  /**
   * check whether file is a PDF
   * @param  {File} file file to be checked
   * @return  {boolean} returns true if valid, false if invalid
   */
  validatePdfFile(file: File): boolean {
    if (file.type == 'application/pdf') {
      return true;
    } else {
      this.alertService.displayWarning('Invalid PDF file!');
      return false;
    }
  }
}
