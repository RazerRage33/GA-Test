import { Contract } from './../interface/Contract';
import { API_URL, HTTP_OPTION } from './../APP_CONFIG';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class ContractService {
  constructor(private http: HttpClient) {}

  /**
   * get contract type
   * @return {Contract[]}  contract type
   */
  getContractType(): Observable<Contract[]> {
    return this.http.get<Contract[]>(
      API_URL + 'Contract/ContractType',
      HTTP_OPTION
    );
  }

  /**
   * get contract
   * @param {string} companyName company to get contract
   * @return {Contract}  contract
   */
  getContract(companyName: string): Observable<Contract[]> {
    return this.http.get<Contract[]>(
      API_URL + 'Contract/ContractByCompanyName/' + companyName,
      HTTP_OPTION
    );
  }

  /**
   * create contract
   * @param {Contract} contract contract to be created
   * @return {any}  response
   */
  createContract(contract: Contract): Observable<any> {
    return this.http.post<any>(
      API_URL + 'Contract/Create',
      contract,
      HTTP_OPTION
    );
  }

  /**
   * create contract
   * @param {Contract} contract contract to be created
   * @return {any}  response
   */
  updateContract(contract: Contract): Observable<any> {
    return this.http.post<any>(
      API_URL + 'Contract/Update',
      contract,
      HTTP_OPTION
    );
  }
}
