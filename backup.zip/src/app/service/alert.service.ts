import { Toast } from './../interface/Toast';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AlertService {
  private toast$ = new BehaviorSubject<Toast>(null!);

  constructor() {}

  /**
   * getter for toast obserable
   * @return — observable of toast
   */
  get toast() {
    return this.toast$.asObservable();
  }

  /**
   * display success toast
   * @param {string} value text to be displayed
   */
  displaySuccess(value: string) {
    const toast: Toast = {
      severity: 'success',
      summary: 'Success',
      detail: value,
    };
    this.toast$.next(toast);
  }

  /**
   * display info toast
   * @param {string} value text to be displayed
   */
  displayInfo(value: string) {
    const toast: Toast = {
      severity: 'info',
      summary: 'Info',
      detail: value,
    };
    this.toast$.next(toast);
  }

  /**
   * display warn toast
   * @param {string} value text to be displayed
   */
  displayWarning(value: string) {
    const toast: Toast = {
      severity: 'warn',
      summary: 'Warning',
      detail: value,
    };
    this.toast$.next(toast);
  }

  /**
   * display error toast
   * @param {string} value text to be displayed
   */
  displayError(value: string) {
    const toast: Toast = {
      severity: 'error',
      summary: 'Error',
      detail: value,
    };
    this.toast$.next(toast);
  }
}
