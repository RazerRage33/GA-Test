import { AlertService } from 'src/app/service/alert.service';
import { ROUTE } from 'src/app/APP_CONFIG';
import { Router } from '@angular/router';
import { AuthService } from './../service/auth.service';
import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpErrorResponse,
} from '@angular/common/http';
import { catchError, Observable, throwError, switchMap } from 'rxjs';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  isRefreshingToken: boolean = false;

  constructor(
    private authService: AuthService,
    private router: Router,
    private alertService: AlertService
  ) {}

  intercept(
    req: HttpRequest<unknown>,
    next: HttpHandler
  ): Observable<HttpEvent<unknown>> {
    return next.handle(req).pipe(
      catchError((err: HttpErrorResponse) => {
        if (err.status == 401) {
          if (this.router.url == '/' + ROUTE.LOGIN || this.isRefreshingToken) {
            return next.handle(req);
          } else {
            this.isRefreshingToken = true;
            return this.handle401Error(req, next, err);
          }
        } else {
          this.handleError(err.status);
          return throwError(() => err);
        }
      })
    );
  }

  private handleError(status: number) {
    switch (status) {
      case 0: {
        this.alertService.displayError('No response from server');
      }
    }
  }

  private handle401Error(
    req: HttpRequest<any>,
    next: HttpHandler,
    originalError: any
  ) {
    return this.authService.refreshCookie().pipe(
      switchMap(() => {
        this.isRefreshingToken = false;
        return next.handle(req);
      }),
      catchError((err) => {
        this.isRefreshingToken = false;
        this.authService.logout().subscribe();
        return throwError(() => originalError);
      })
    );
  }
}
