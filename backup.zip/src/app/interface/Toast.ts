export interface Toast {
  severity: string;
  summary: string;
  detail: string;
}
