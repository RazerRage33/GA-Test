export interface Project {
    id?: string;
    name?: string;
    description?: string;
    createdByUsername?: string;
    createdOn?: string;
    updatedByUsername?: string;
    updatedOn?: string; 

    // link company
    projectName?: string;
    companyName?: string;
    
    // update
    oldName?: string;
}